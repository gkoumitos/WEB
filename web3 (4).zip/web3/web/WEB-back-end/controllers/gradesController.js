// controllers/gradesController.js
// Χωρίς queryOne – μόνο db.query(...)

const db = require('../db'); // <-- βεβαιώσου ότι αυτό σου γυρίζει pool με .query()

// Utility: φέρνει ένα row (ή null)
async function fetchOne(sql, params = []) {
  const [rows] = await db.query(sql, params);
  return rows && rows.length ? rows[0] : null;
}

// GET /api/grades/:thesisId  -> όλοι οι βαθμοί της διπλωματικής
exports.list = async (req, res, next) => {
  try {
    const thesisId = Number(req.params.thesisId);
    const [rows] = await db.query(
      `SELECT g.id, g.thesis_id, g.grader_id, g.criterion_1, g.criterion_2, g.criterion_3,
              g.overall, g.submitted_at,
              u.first_name, u.last_name, u.email
         FROM grades g
         JOIN users  u ON u.id = g.grader_id
        WHERE g.thesis_id = ?
        ORDER BY g.submitted_at DESC, g.id DESC`,
      [thesisId]
    );
    res.json(rows || []);
  } catch (err) {
    next(err);
  }
};

// GET /api/grades/:thesisId/mine -> ο δικός μου βαθμός (αν υπάρχει)
exports.mine = async (req, res, next) => {
  try {
    const thesisId = Number(req.params.thesisId);
    const graderId = Number(req.user.id);

    const row = await fetchOne(
      `SELECT id, thesis_id, grader_id, criterion_1, criterion_2, criterion_3, overall, submitted_at
         FROM grades
        WHERE thesis_id = ? AND grader_id = ?`,
      [thesisId, graderId]
    );

    res.json(row || null);
  } catch (err) {
    next(err);
  }
};

// POST /api/grades/:thesisId/mine -> insert/update ο δικός μου βαθμός
// Δέχεται:
//   - μόνο { overall }
//   - ή { criterion_1, criterion_2, criterion_3 } (+ προαιρετικά overall)
// Αν λείπει overall και υπάρχουν κριτήρια, υπολογίζει μέσο όρο.
exports.upsertMine = async (req, res, next) => {
  try {
    const thesisId = Number(req.params.thesisId);
    const graderId = Number(req.user.id);

    // Δέξου και payload με nested criteria: { criteria: {criterion_1,...}, overall }
    const p = req.body || {};
    const criteria = p.criteria || {};
    let c1 = Number(p.criterion_1 ?? criteria.criterion_1 ?? 0);
    let c2 = Number(p.criterion_2 ?? criteria.criterion_2 ?? 0);
    let c3 = Number(p.criterion_3 ?? criteria.criterion_3 ?? 0);

    let overall = (p.overall !== undefined && p.overall !== null)
      ? Number(p.overall)
      : null;

    // Αν δεν ήρθε overall αλλά ήρθαν κριτήρια -> υπολόγισέ το
    const haveAnyCriterion = !Number.isNaN(c1) || !Number.isNaN(c2) || !Number.isNaN(c3);
    if ((overall === null || Number.isNaN(overall)) && haveAnyCriterion) {
      // ό,τι δεν είναι αριθμός το κάνουμε 0
      c1 = Number.isNaN(c1) ? 0 : c1;
      c2 = Number.isNaN(c2) ? 0 : c2;
      c3 = Number.isNaN(c3) ? 0 : c3;
      overall = Number(((c1 + c2 + c3) / 3).toFixed(1));
    }

    // Αν δεν υπάρχει ούτε overall ούτε κριτήρια -> bad request
    if ((overall === null || Number.isNaN(overall)) && !haveAnyCriterion) {
      return res.status(400).json({ error: 'Missing field: overall or criteria' });
    }

    // Υπάρχει ήδη βαθμός αυτού του grader για τη συγκεκριμένη διπλωματική;
    const existing = await fetchOne(
      `SELECT id FROM grades WHERE thesis_id = ? AND grader_id = ? LIMIT 1`,
      [thesisId, graderId]
    );

    if (existing) {
      // UPDATE
      await db.query(
        `UPDATE grades
            SET criterion_1 = ?, criterion_2 = ?, criterion_3 = ?, overall = ?, submitted_at = NOW()
          WHERE id = ?`,
        [c1 || 0, c2 || 0, c3 || 0, overall, existing.id]
      );
    } else {
      // INSERT
      await db.query(
        `INSERT INTO grades (thesis_id, grader_id, criterion_1, criterion_2, criterion_3, overall, submitted_at)
         VALUES (?, ?, ?, ?, ?, ?, NOW())`,
        [thesisId, graderId, c1 || 0, c2 || 0, c3 || 0, overall]
      );
    }

    // Επέστρεψε το (επικαιροποιημένο) δικό μου grade
    const updated = await fetchOne(
      `SELECT id, thesis_id, grader_id, criterion_1, criterion_2, criterion_3, overall, submitted_at
         FROM grades
        WHERE thesis_id = ? AND grader_id = ?
        ORDER BY submitted_at DESC, id DESC
        LIMIT 1`,
      [thesisId, graderId]
    );

    res.json(updated);
  } catch (err) {
    next(err);
  }
};
