const router = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/usersController');

router.get('/me', authenticate, ctrl.getMe);
router.put('/me', authenticate, ctrl.updateMe);

// Αναζήτηση φοιτητών (για διδάσκοντες / γραμματεία)
router.get('/search', authenticate, authorize('faculty','secretariat'), ctrl.searchStudents);

const users = require('../controllers/usersController');
router.get('/by-code/:code',
  authenticate,
  authorize('faculty'),
  users.getByCode
);

module.exports = router;