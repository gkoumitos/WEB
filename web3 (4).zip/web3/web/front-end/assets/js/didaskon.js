// front-end/assets/js/didaskon.js
import { API } from '../js/api.js';

/* ---------- helpers ---------- */
function escapeHtml(s='') {
  return s.replace(/[&<>"']/g, c =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]
  );
}

// Επιστρέφει τα *δικά μου* θέματα (δουλεύει είτε έχεις topics.mine είτε topics.listMine)
async function getMyTopics() {
  if (API.topics?.listMine) return API.topics.listMine();
  return API.topics.mine();
}

/* ---------- Θεματολόγιο ---------- */
async function loadTopics(){
  const list = document.getElementById('topicsList');
  if (!list) return;

  try{
    const data = await getMyTopics();
    list.innerHTML = (Array.isArray(data) && data.length)
      ? data.map(t => {
          const active = (t.is_active === true) || (Number(t.is_active) === 1);
          const pdfUrl = t.pdf || t.description_file || null;
          return `
            <li class="list-group-item d-flex justify-content-between align-items-start">
              <div>
                <h6 class="mb-1">${escapeHtml(t.title || '(χωρίς τίτλο)')}</h6>
                <small class="text-muted">${escapeHtml(t.summary || '')}</small><br>
                ${pdfUrl ? `<small><a href="${pdfUrl}" target="_blank" rel="noopener">📄 Αρχείο</a></small>` : ''}
                ${active ? ` <span class="badge bg-success">ενεργό</span>` : ` <span class="badge bg-secondary">ανενεργό</span>`}
              </div>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-secondary"
                        data-toggle="${t.id}" data-active="${active ? '1' : '0'}">
                  ${active ? 'Απενεργοποίηση' : 'Ενεργοποίηση'}
                </button>
              </div>
            </li>`;
        }).join('')
      : '<li class="list-group-item text-muted">— Δεν υπάρχουν θέματα —</li>';

    // toggle ενεργό/ανενεργό
    list.querySelectorAll('[data-toggle]').forEach(btn=>{
      btn.addEventListener('click', async ()=>{
        const id = btn.dataset.toggle;
        const isActive = btn.dataset.active === '1';
        try {
          if (API.topics?.update) {
            await API.topics.update(id, { is_active: !isActive });
          } else if (API.topics?.toggle) {
            await API.topics.toggle(id, !isActive);
          } else {
            throw new Error('Δεν βρέθηκε endpoint για ενημέρωση θέματος.');
          }
          await loadTopics();
        } catch (e) {
          console.error(e); alert(e.message || e);
        }
      });
    });

  }catch(e){
    console.error('[didaskon] loadTopics error:', e);
    list.innerHTML = `<li class="list-group-item text-danger">${e.message || e}</li>`;
  }
}

function createTopic(){
  const f = document.getElementById('topicForm');
  if (!f) return;

  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const title   = f.elements['title'].value.trim();
      const summary = f.elements['summary'].value.trim();
      if (!title) throw new Error('Δώσε τίτλο θέματος');

      // προαιρετικό PDF
      let pdf = null;
      const file = f.elements['pdf']?.files?.[0];
      if (file) {
        const fd = new FormData(); fd.append('file', file);
        try {
          const up = await API.files.upload(fd); // { path }
          pdf = up?.path || null;
        } catch (err) {
          console.error('[didaskon] upload error:', err);
          alert('Αποτυχία ανεβάσματος αρχείου. Συνεχίζουμε χωρίς PDF.');
        }
      }

      if (API.topics?.create) {
        await API.topics.create({ title, summary, pdf });
      } else {
        throw new Error('Δεν υπάρχει endpoint API.topics.create');
      }
      f.reset();
      await loadTopics();
    } catch (e2) {
      console.error(e2); alert(e2.message || e2);
    }
  });
}

/* ---------- Προσκλήσεις (αν τις χρησιμοποιείς) ---------- */
/* ---------- Προσκλήσεις ---------- */
async function loadInvitations(){
  const box = document.getElementById('invitationsList');
  if (!box || !API.invitations?.mine) return;

  try {
    const invs = await API.invitations.mine();
    box.innerHTML = (invs && invs.length)
      ? invs.map(inv => {
          const dt = inv.invited_at ? new Date(inv.invited_at).toLocaleString('el-GR') : '—';
          return `
            <div class="card mb-2" data-id="${inv.id}">
              <div class="card-body d-flex justify-content-between align-items-start">
                <div class="me-3">
                  <div><strong>${escapeHtml(inv.title || '(χωρίς τίτλο)')}</strong></div>
                  <div class="text-muted">Ημ/νία: ${dt}</div>
                </div>
                <div class="btn-group">
                  <button class="btn btn-sm btn-success btn-accept">✔ Αποδοχή</button>
                  <button class="btn btn-sm btn-danger btn-decline">✖ Απόρριψη</button>
                </div>
              </div>
            </div>`;
        }).join('')
      : `<div class="alert alert-info">Δεν υπάρχουν προσκλήσεις.</div>`;

    // wire up buttons
    box.querySelectorAll('.btn-accept').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.closest('.card').dataset.id;
        try {
          await API.invitations.accept(id);
          await loadInvitations(); // refresh λίστα
        } catch (err) {
          alert('Αποτυχία αποδοχής: ' + (err.message || err));
        }
      });
    });

    box.querySelectorAll('.btn-decline').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.closest('.card').dataset.id;
        try {
          await API.invitations.decline(id);
          await loadInvitations(); // refresh λίστα
        } catch (err) {
          alert('Αποτυχία απόρριψης: ' + (err.message || err));
        }
      });
    });

  } catch(e) {
    box.innerHTML = `<div class="text-danger">${e.message || e}</div>`;
  }
}

/* ---------- Οι διπλωματικές μου (προαιρετικό) ---------- */
async function loadMyTheses(){
  const tbody = document.querySelector('#diplomatikesTable tbody');
  if (!tbody || !API.theses?.mine) return;
  try{
    const rows = await API.theses.mine();
    tbody.innerHTML = (rows||[]).map(r => `
      <tr data-id="${r.id}">
        <td>${escapeHtml(r.title || '-')}</td>
        <td>${escapeHtml((r.student_last_name||'') + ' ' + (r.student_first_name||''))}</td>
        <td>${escapeHtml(r.status || '-')}</td>
        <td>${r.supervisor_id === r.me ? 'επιβλέπων' : 'μέλος'}</td>
      </tr>
    `).join('') || `<tr><td colspan="4" class="text-center text-muted">— Καμία —</td></tr>`;
  }catch(e){
    tbody.innerHTML = `<tr><td colspan="4" class="text-danger">${e.message || e}</td></tr>`;
  }
}

/* ---------- Αναθέσεις ---------- */
let _assignInitDone = false;

async function fillTopicsForAssign() {
  const sel = document.getElementById('assign-topic');
  if (!sel) return;
  sel.innerHTML = `<option value="">— Επιλογή —</option>`;
  try {
    const topics = await getMyTopics(); // [{id,title,...}]
    if (Array.isArray(topics)) {
      sel.innerHTML += topics.map(t =>
        `<option value="${t.id}">${escapeHtml(t.title)}</option>`
      ).join('');
    }
  } catch (e) {
    console.error('[assign] load topics failed:', e);
  }
}

// ====== helpers ======
const assignSearchCache = { students: [] };

function labelForStudent(s) {
  return `${s.last_name} ${s.first_name} (${s.email})`;
}

function extractEmail(str) {
  if (!str) return '';
  const m = String(str).match(/\(([^)]+)\)\s*$/);
  return m ? m[1].trim() : '';
}

function pickStudentIdFromCache(typed) {
  if (!typed) return 0;
  const t = typed.trim();
  const tLower = t.toLowerCase();

  // 1) αν έχει email στο input -> ακριβές match email
  const typedEmail = extractEmail(t);
  if (typedEmail) {
    const m = assignSearchCache.students.find(
      s => String(s.email || '').toLowerCase() === typedEmail.toLowerCase()
    );
    if (m) return Number(m.id);
  }

  // 2) ακριβής label (όπως το δημιουργούμε) case-insensitive
  const byLabel = assignSearchCache.students.find(
    s => labelForStudent(s).toLowerCase() === tLower
  );
  if (byLabel) return Number(byLabel.id);

  // 3) μοναδικό αποτέλεσμα στο cache
  if (assignSearchCache.students.length === 1) {
    return Number(assignSearchCache.students[0].id);
  }

  return 0;
}

// ====== search wiring ======
// ===== helpers =====

// ----- wireStudentSearch -----
// ===== helpers =====

function wireStudentSearch() {
  const inp = document.getElementById('assign-student');
  const dl  = document.getElementById('students-dl');
  if (!inp || !dl || !API.users?.searchStudents) {
    console.warn('[assign] wireStudentSearch: missing elements or API');
    return;
  }

  let timer = null;

  inp.addEventListener('input', () => {
    clearTimeout(timer);
    const q = (inp.value || '').trim();
    inp.dataset.studentId = '';
    dl.innerHTML = '';
    assignSearchCache.students = [];
    if (!q) return;

    timer = setTimeout(async () => {
      try {
        console.log('[assign] searchStudents(query)=', q);
        const arr = await API.users.searchStudents(q);
        assignSearchCache.students = Array.isArray(arr) ? arr : [];
        console.log('[assign] candidates from API=', assignSearchCache.students);

        dl.innerHTML = assignSearchCache.students.map(s =>
          `<option data-id="${s.id}" value="${labelForStudent(s)}"></option>`
        ).join('');

        // auto lock αν γράφτηκε ακριβές label
        const current = (inp.value || '').trim().toLowerCase();
        const m = assignSearchCache.students.find(s =>
          labelForStudent(s).toLowerCase() === current
        );
        inp.dataset.studentId = m ? String(m.id) : '';
        console.log('[assign] auto-locked dataset.studentId=', inp.dataset.studentId);
      } catch (err) {
        console.warn('[assign] search failed:', err);
      }
    }, 250);
  });

  const tryResolve = () => {
    const t = (inp.value || '').trim().toLowerCase();
    const byLabel = assignSearchCache.students.find(
      s => labelForStudent(s).toLowerCase() === t
    );
    const email = extractEmail(inp.value);
    const byEmail = assignSearchCache.students.find(
      s => (s.email || '').toLowerCase() === (email || '').toLowerCase()
    );
    const chosen = byLabel || byEmail || null;
    inp.dataset.studentId = chosen ? String(chosen.id) : '';
    console.log('[assign] tryResolve → dataset.studentId=', inp.dataset.studentId);
  };
  inp.addEventListener('input', tryResolve);
  inp.addEventListener('change', tryResolve);
  inp.addEventListener('blur', tryResolve);
}


// ====== submit wiring (robust fallback) ======
function wireAssignSubmit() {
  const btn  = document.getElementById('assign-submit');
  const inp  = document.getElementById('assign-student');
  const sel  = document.getElementById('assign-topic');
  const file = document.getElementById('assign-pdf');

  if (!btn || !inp || !sel || !API.theses?.create || !API.users?.searchStudents) {
    console.warn('[assign] wireAssignSubmit: missing DOM or API');
    return;
  }

  btn.addEventListener('click', async () => {
    try {
      const typedRaw = (inp.value || '').trim();
      const typed = typedRaw.normalize('NFKC');
      let student_id = Number(inp.dataset.studentId || 0);
      const topic_id  = Number(sel.value || 0);

      console.log('--- ASSIGN CLICK ---');
      console.log('typed=', typed, 'dataset.studentId=', inp.dataset.studentId, 'topic_id=', topic_id);

      // 1) Αν δεν έχουμε ακόμη id, κάνε LIVE αναζήτηση στο backend
      if (!student_id) {
        const q = typed || extractEmail(typed);
        if (!q) {
          alert('Διάλεξε φοιτητή από τη λίστα.');
          console.warn('[assign] empty query for search');
          return;
        }

        let candidates = [];
        try {
          console.log('[assign] live search with q=', q);
          candidates = await API.users.searchStudents(q);
        } catch (e) {
          console.warn('[assign] live search failed:', e);
        }
        candidates = Array.isArray(candidates) ? candidates : [];
        console.log('[assign] live candidates=', candidates);

        const email = extractEmail(typed);
        let chosen = null;

        if (email) {
          chosen = candidates.find(s =>
            String(s.email || '').toLowerCase() === email.toLowerCase()
          ) || null;
          console.log('[assign] chosen by email=', chosen);
        }
        if (!chosen && candidates.length === 1) {
          chosen = candidates[0];
          console.log('[assign] chosen single result=', chosen);
        }
        if (!chosen) {
          const tLower = typed.toLowerCase();
          chosen = candidates.find(
            s => labelForStudent(s).toLowerCase() === tLower
          ) || null;
          console.log('[assign] chosen by label match=', chosen);
        }
        // *** Επιθετικό fallback: αν έχουμε έστω 1 αποτέλεσμα, πάρε το πρώτο ***
        if (!chosen && candidates.length > 0) {
          chosen = candidates[0];
          console.log('[assign] fallback chosen first=', chosen);
        }

        if (!chosen) {
          alert('Διάλεξε φοιτητή από τη λίστα.');
          console.warn('[assign] no candidate chosen for typed=', typed, 'candidates=', candidates);
          return;
        }

        student_id = Number(chosen.id);
        inp.dataset.studentId = String(student_id);
        inp.value = labelForStudent(chosen);
        console.log('[assign] resolved student_id=', student_id, 'input normalized to=', inp.value);
      }

      if (!topic_id) {
        alert('Διάλεξε θέμα.');
        console.warn('[assign] missing topic_id');
        return;
      }

      // 2) Προαιρετικό PDF
      let pdf = null;
      const f = file?.files?.[0];
      if (f && API.files?.upload) {
        try {
          const fd = new FormData();
          fd.append('file', f);
          const up = await API.files.upload(fd); // { path }
          pdf = up?.path || null;
          console.log('[assign] uploaded file →', pdf);
        } catch (e) {
          console.warn('[assign] upload failed:', e);
          alert('Το PDF δεν ανέβηκε. Συνεχίζουμε χωρίς PDF.');
        }
      }

      // 3) Δημιουργία ανάθεσης
      console.log('[assign] creating thesis with', { topic_id, student_id, pdf });
      await API.theses.create({ topic_id, student_id, pdf });
      alert('Η ανάθεση καταχωρήθηκε.');

      // reset
      inp.value = ''; inp.dataset.studentId = '';
      if (sel)  sel.value = '';
      if (file) file.value = '';
      console.log('--- ASSIGN DONE ---');

    } catch (err) {
      console.error('[assign] submit error:', err);
      alert(err?.message || 'Αποτυχία ανάθεσης');
    }
  });
}

async function initAssign() {
  if (_assignInitDone) return;
  const studentInput = document.getElementById('assign-student');
  const topicSelect  = document.getElementById('assign-topic');
  const fileInput    = document.getElementById('assign-pdf');
  const btnAssign    = document.getElementById('assign-submit');

  // Αν λείπει κάτι από το DOM, μην κάνεις τίποτα
  if (!studentInput || !topicSelect || !btnAssign) {
    console.warn('[assign] missing DOM elements');
    return;
  }
  _assignInitDone = true;

  // Γέμισε τα θέματα στο dropdown
  await fillTopicsForAssign();

  btnAssign.addEventListener('click', async () => {
    try {
      const code = (studentInput.value || '').trim().toUpperCase();

      // 1) Βασικός έλεγχος ΑΜ φοιτητή: A + ψηφία
      if (!/^A\d+$/.test(code)) {
        alert('Δώσε ΑΜ φοιτητή που να αρχίζει από A (π.χ. A10023).');
        return;
      }

      // 2) Φέρε το student από το code (ο client σου επιστρέφει ήδη JSON)
      let student = null;
      try {
        student = await API.users.getByCode(code); // ΔΕΝ βάζεις .json()
      } catch (_) {
        student = null;
      }

      if (!student || !student.id) {
        alert('Δεν βρέθηκε φοιτητής με αυτόν τον ΑΜ ή δεν είναι ρόλος φοιτητή.');
        return;
      }

      // 3) Διάλεξε θέμα
      const topicId = Number(topicSelect.value || 0);
      if (!topicId) {
        alert('Διάλεξε θέμα.');
        return;
      }

      // 4) (Προαιρετικό) ανέβασμα PDF
      let pdf = null;
      const file = fileInput?.files?.[0];
      if (file && API.files?.upload) {
        try {
          const fd = new FormData();
          fd.append('file', file);
          const up = await API.files.upload(fd); // { path }
          pdf = up?.path || null;
        } catch (e) {
          console.warn('[assign] upload failed:', e);
          alert('Το PDF δεν ανέβηκε. Συνεχίζουμε χωρίς PDF.');
        }
      }

      // 5) Δημιούργησε την ανάθεση
      const payload = {
        student_id: student.id,
        topic_id: topicId,
        pdf
      };

      // Χρησιμοποίησε το create (όχι assign)
      await API.theses.create(payload);

      alert('Η ανάθεση καταχωρήθηκε.');
      // reset
      studentInput.value = '';
      topicSelect.value  = '';
      if (fileInput) fileInput.value = '';
    } catch (err) {
      console.error(err);
      alert('Κάτι πήγε στραβά κατά την ανάθεση.');
    }
  });
}

// ========== ΣΤΑΤΙΣΤΙΚΑ ==========
let _statsCharts = { grades: null, days: null };

async function loadFacultyStats() {
  if (!API.stats?.mine) return;
  try {
    const s = await API.stats.mine();

    // Γέμισμα μετρικών
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set('st-supervised-total',   s.total_supervised);
    set('st-committee-total',    s.total_member);

    set('st-supervised-avggrade', s.avg_grade_supervisor ? s.avg_grade_supervisor.toFixed(2) : '–');
    set('st-committee-avggrade',  s.avg_grade_member     ? s.avg_grade_member.toFixed(2)     : '–');

    set('st-supervised-avgdays',  s.avg_days_supervisor  ? Math.round(s.avg_days_supervisor) : '–');
    set('st-committee-avgdays',   s.avg_days_member      ? Math.round(s.avg_days_member)     : '–');

    // Κατέστρεψε προηγούμενα charts (για να μη διπλασιάζονται στις εναλλαγές tab)
    if (_statsCharts.grades) { _statsCharts.grades.destroy?.(); _statsCharts.grades = null; }
    if (_statsCharts.days)   { _statsCharts.days.destroy?.();   _statsCharts.days   = null; }

    // Γραφήματα
    const gradesCtx = document.getElementById('statsGradesChart');
    const daysCtx   = document.getElementById('statsDaysChart');

    if (gradesCtx && window.Chart) {
      _statsCharts.grades = new Chart(gradesCtx, {
        type: 'bar',
        data: {
          labels: ['Ως Επιβλέπων', 'Ως Μέλος'],
          datasets: [{
            label: 'Μέσος βαθμός',
            data: [
              s.avg_grade_supervisor ?? 0,
              s.avg_grade_member ?? 0
            ]
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: { y: { beginAtZero: true, max: 10 } }
        }
      });
    }

    if (daysCtx && window.Chart) {
      _statsCharts.days = new Chart(daysCtx, {
        type: 'bar',
        data: {
          labels: ['Ως Επιβλέπων', 'Ως Μέλος'],
          datasets: [{
            label: 'Μέσος χρόνος (ημέρες)',
            data: [
              s.avg_days_supervisor ?? 0,
              s.avg_days_member ?? 0
            ]
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } },
          scales: { y: { beginAtZero: true } }
        }
      });
    }
  } catch (e) {
    console.error('[stats] loadFacultyStats failed:', e);
  }
}

/* ===================== ΔΙΑΧΕΙΡΙΣΗ ΔΙΠΛΩΜΑΤΙΚΩΝ (Διδάσκων) ===================== */

const DM = { currentThesisId: null };

function badgeForStatus(s) {
  const map = { proposed:'secondary', active:'success', under_review:'warning', completed:'primary', cancelled:'dark' };
  const txt = { proposed:'Υπό Ανάθεση', active:'Ενεργή', under_review:'Υπό Εξέταση', completed:'Περατωμένη', cancelled:'Ακυρωμένη' };
  return `<span class="badge bg-${map[s]||'secondary'}">${txt[s]||s}</span>`;
}

function rolePill(isSupervisor) {
  return isSupervisor ? `<span class="badge rounded-pill text-bg-primary">επιβλέπων</span>`
                      : `<span class="badge rounded-pill text-bg-secondary">μέλος</span>`;
}

function actionButtons(th) {
  const isSup = th.supervisor_id === th.me;           // backend επιστρέφει me=id τρέχοντος διδάσκοντα
  const s = th.status;
  const b = [];

  if (s === 'proposed') {
    b.push(`<button class="btn btn-sm btn-outline-secondary" data-act="showInv" data-id="${th.id}">Προσκλήσεις</button>`);
    if (isSup) b.push(`<button class="btn btn-sm btn-outline-danger" data-act="cancel" data-id="${th.id}">Ακύρωση ανάθεσης</button>`);
  }

  if (s === 'active') {
    b.push(`<button class="btn btn-sm btn-outline-secondary" data-act="notes" data-id="${th.id}">Σημειώσεις μου</button>`);
    if (isSup) {
      b.push(`<button class="btn btn-sm btn-outline-warning" data-act="toReview" data-id="${th.id}">Θέσε "Υπό Εξέταση"</button>`);
      b.push(`<button class="btn btn-sm btn-outline-danger" data-act="cancel" data-id="${th.id}">Ακύρωση ανάθεσης</button>`);
    }
  }

  if (s === 'under_review') {
    b.push(`<button class="btn btn-sm btn-outline-secondary" data-act="showDraft" data-id="${th.id}">Δες πρόχειρο/links</button>`);
    // Προϋπόθεση ανακοίνωσης: θα την ενεργοποιήσεις όταν έχεις endpoint με review info
    b.push(`<button class="btn btn-sm btn-outline-secondary" data-act="grade" data-id="${th.id}">Καταχώρηση βαθμού</button>`);
    // Προβολή βαθμών άλλων μελών γίνεται μέσα στο ίδιο modal
  }

  return b.join(' ');
}

async function loadManageTheses() {
  const wrap = document.getElementById('manageThesesList');
  if (!wrap) return;
  wrap.innerHTML = `<div class="text-muted">Φόρτωση…</div>`;

  try {
    const rows = await API.theses.mine(); // backend σου επιστρέφει και πεδίο 'me' για το τρέχον id
    if (!Array.isArray(rows) || rows.length === 0) {
      wrap.innerHTML = `<div class="alert alert-info mb-0">Δεν βρέθηκαν διπλωματικές.</div>`;
      return;
    }

    wrap.innerHTML = rows.map(th => `
      <div class="card" data-id="${th.id}">
        <div class="card-body d-flex justify-content-between align-items-start">
          <div class="me-3">
            <div class="mb-2">${badgeForStatus(th.status)} ${rolePill(th.supervisor_id === th.me)}</div>
            <div class="fw-semibold">${(th.title||'').replace(/</g,'&lt;')}</div>
            <div class="text-muted small">
              Φοιτητής/τρια: ${(th.student_last_name||'')+' '+(th.student_first_name||'')}
            </div>
          </div>
          <div class="btn-group">${actionButtons(th)}</div>
        </div>
      </div>
    `).join('');

    // delegate actions
    wrap.querySelectorAll('button[data-act]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id  = Number(btn.dataset.id);
        const act = btn.dataset.act;
        DM.currentThesisId = id;

        try {
          if (act === 'showInv')      return showInvitations(id);
          if (act === 'cancel')       return openCancelModal(id);
          if (act === 'notes')        return openNotesModal(id);
          if (act === 'toReview')     return setUnderReview(id);
          if (act === 'showDraft')    return showDraftLinks(id);
          if (act === 'grade')        return openGradeModal(id);
        } catch(e) {
          console.error(e); alert(e.message || e);
        }
      });
    });

  } catch (e) {
    console.error(e);
    wrap.innerHTML = `<div class="text-danger">Σφάλμα: ${e.message || e}</div>`;
  }
}

/* ----- Υπό Ανάθεση: Προσκλήσεις ----- */
async function showInvitations(thesisId) {
  if (!API.invitations?.byThesis) {
    return alert('Δεν υπάρχει endpoint για προβολή προσκλήσεων ανά διπλωματική.');
  }
  const list = await API.invitations.byThesis(thesisId);
  const msg = (list||[]).map(i => {
    const s = (i.response||'pending');
    const inv = i.invited_at ? new Date(i.invited_at).toLocaleString('el-GR') : '—';
    const res = i.responded_at ? new Date(i.responded_at).toLocaleString('el-GR') : '—';
    return `• ${i.faculty_last_name} ${i.faculty_first_name} — ${s} (πρόσκληση: ${inv}, απάντηση: ${res})`;
  }).join('\n') || '— Καμία πρόσκληση —';
  alert(msg);
}

/* ----- Ενεργή: Σημειώσεις ----- */
let _notesModal, _cancelModal, _gradeModal;
function bsModal(id){ return _ => (_ ||= new bootstrap.Modal(document.getElementById(id))); }

_notesModal  = bsModal('notesModal')();
_cancelModal = bsModal('cancelModal')();
_gradeModal  = bsModal('gradeModal')();

async function openNotesModal(thesisId) {
  const ul   = document.getElementById('notesList');
  const inp  = document.getElementById('newNoteText');
  const add  = document.getElementById('addNoteBtn');
  ul.innerHTML = `<li class="list-group-item text-muted">Φόρτωση…</li>`;

  const paint = (rows) => {
    ul.innerHTML = rows.length
      ? rows.map(n => `
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <span class="small">${(n.text||'').replace(/</g,'&lt;')}</span>
            <button class="btn btn-sm btn-outline-danger" data-del="${n.id}">Διαγραφή</button>
          </li>`).join('')
      : `<li class="list-group-item text-muted">— Καμία σημείωση —</li>`;
    ul.querySelectorAll('button[data-del]').forEach(b=>{
      b.addEventListener('click', async ()=>{
        await API.notes.remove(b.dataset.del);
        paint(await API.notes.mine(thesisId));
      });
    });
  };

  paint(await API.notes.mine(thesisId));

  add.onclick = async ()=>{
    const t = (inp.value||'').trim();
    if (!t) return;
    await API.notes.create(thesisId, t);
    inp.value = '';
    paint(await API.notes.mine(thesisId));
  };

  _notesModal.show();
}

/* ----- Ενεργή: Θέσε Υπό Εξέταση ----- */
async function setUnderReview(thesisId) {
  if (!confirm('Θέλεις να θέσεις τη διπλωματική "Υπό Εξέταση";')) return;
  await API.theses.changeStatus(thesisId, 'under_review');
  alert('Η διπλωματική τέθηκε "Υπό Εξέταση".');
  loadManageTheses();
}

/* ----- Ενεργή/Προτεινόμενη: Ακύρωση ----- */
function openCancelModal(thesisId) {
  const no   = document.getElementById('cancelDecisionNo');
  const year = document.getElementById('cancelDecisionYear');
  const go   = document.getElementById('confirmCancelBtn');

  no.value = ''; year.value = '';

  go.onclick = async ()=>{
    const payload = { decision_no: (no.value||'').trim(), decision_year: (year.value||'').trim() };
    await API.theses.cancel(thesisId, payload);
    _cancelModal.hide();
    alert('Η ανάθεση ακυρώθηκε.');
    loadManageTheses();
  };

  _cancelModal.show();
}

/* ----- Υπό Εξέταση: Πρόχειρο & links ----- */
async function showDraftLinks(thesisId) {
  let txt = '';
  try {
    const draft = await API.theses.getDraft(thesisId);    // { path: '/uploads/...' } ή 204
    txt += draft?.path ? `Πρόχειρο: ${draft.path}\n` : 'Πρόχειρο: —\n';

    const links = await API.theses.listLinks(thesisId);   // [{url:...}]
    if (Array.isArray(links) && links.length) {
      txt += 'Links:\n' + links.map(x=>`• ${x.url}`).join('\n');
    } else {
      txt += 'Links: —';
    }
  } catch(e) {
    txt = 'Δεν βρέθηκε πρόχειρο/links.';
  }
  alert(txt);
}

async function refreshGradesList(thesisId, hostEl) {
  try {
    // 1) Βρες/ετοίμασε το slot που θα δείξει τους βαθμούς
    const slot = (() => {
      // α) Αν μας έδωσαν hostEl, δοκίμασε να βρεις μέσα του grades-slot
      if (hostEl) {
        let s = hostEl.querySelector('.grades-slot');
        if (!s) {
          s = document.createElement('div');
          s.className = 'grades-slot small text-muted mt-1';
          hostEl.appendChild(s);
        }
        return s;
      }
      // β) Αλλιώς εντόπισε την κάρτα του θέματος από το thesisId
      //    Προτιμάμε να υπάρχει data-thesis-id="..." στο wrapper της κάρτας.
      let card = document.querySelector(`[data-thesis-id="${thesisId}"]`);
      if (!card) {
        // fallback: ψάξε ένα κοντινό κουμπί που άνοιξε το modal και ανέβα ως parent
        card = document.querySelector(`[data-thesisid="${thesisId}"]`) || document.body;
      }
      let s = card.querySelector('.grades-slot');
      if (!s) {
        s = document.createElement('div');
        s.className = 'grades-slot small text-muted mt-1';
        card.appendChild(s);
      }
      return s;
    })();

    // 2) Φέρε τους βαθμούς (όλων των μελών) για αυτό το θέμα
    // Δουλεύουμε defensively με όποια μέθοδο υπάρχει στο API.
    let rows = [];
    if (API.grades?.listByThesis) {
      rows = await API.grades.listByThesis(thesisId);  // προτιμώμενο όνομα
    } else if (API.grades?.all) {
      rows = await API.grades.all(thesisId);           // εναλλακτικό
    } else if (API.grades?.list) {
      rows = await API.grades.list(thesisId);          // εναλλακτικό
    } else if (API.grades?.listMine) {
      // fallback (δεν έχει όλους, αλλά τουλάχιστον δεν "σκάει")
      rows = await API.grades.listMine(thesisId);
    }

    rows = Array.isArray(rows) ? rows : [];

    // 3) Απόδοση στη σελίδα
    if (!rows.length) {
      slot.innerHTML = `<em>Δεν υπάρχουν καταχωρημένοι βαθμοί ακόμη.</em>`;
      return;
    }

    slot.innerHTML = rows.map(r => {
      const who = (r.grader_last_name || r.grader_first_name)
        ? `${(r.grader_last_name || '')} ${(r.grader_first_name || '')}`.trim()
        : (r.grader_email || r.grader_id || 'Μέλος τριμελούς');
      const ov = (r.overall != null) ? Number(r.overall).toFixed(1) : '—';
      const when = r.submitted_at
        ? new Date(r.submitted_at).toLocaleString('el-GR')
        : '';
      return `<div>• ${who}: <strong>${ov}</strong>${when ? ` — <small>${when}</small>` : ''}</div>`;
    }).join('');
  } catch (err) {
    console.warn('[grades] list failed', err);
    alert(err?.message || 'Αποτυχία λήψης βαθμών');
  }
}



/* ----- Υπό Εξέταση: Βαθμολογία ----- */
function openGradeModal(thesisId, hostEl) {
  const wrap = document.getElementById('gradeModal');
  if (!wrap) {
    alert('Δεν βρέθηκε το modal βαθμολογίας στο HTML.');
    return;
  }

  const overallEl = wrap.querySelector('#gradeOverall');
  const critBox   = wrap.querySelector('#criteriaInputs');
  const saveBtn   = wrap.querySelector('#saveGradeBtn');

  // καθάρισε inputs
  overallEl.value = '';
  critBox.innerHTML = `
    <div class="row g-2">
      <div class="col"><input id="crit1" class="form-control form-control-sm" placeholder="κριτήριο 1"></div>
      <div class="col"><input id="crit2" class="form-control form-control-sm" placeholder="κριτήριο 2"></div>
      <div class="col"><input id="crit3" class="form-control form-control-sm" placeholder="κριτήριο 3"></div>
    </div>
  `;

  const c1El = critBox.querySelector('#crit1');
  const c2El = critBox.querySelector('#crit2');
  const c3El = critBox.querySelector('#crit3');

  // καθάρισε παλιό handler
  saveBtn.replaceWith(saveBtn.cloneNode(true));
  const freshSaveBtn = wrap.querySelector('#saveGradeBtn');

  freshSaveBtn.addEventListener('click', async () => {
    try {
      const overall = overallEl.value.trim();
      const payload = { overall: overall ? Number(overall.replace(',', '.')) : undefined };

      const k1 = c1El.value.trim();
      const k2 = c2El.value.trim();
      const k3 = c3El.value.trim();

      if (k1 || k2 || k3) {
        payload.criterion_1 = k1 ? Number(k1.replace(',', '.')) : 0;
        payload.criterion_2 = k2 ? Number(k2.replace(',', '.')) : 0;
        payload.criterion_3 = k3 ? Number(k3.replace(',', '.')) : 0;

        if (payload.overall === undefined) {
          payload.overall = (payload.criterion_1 + payload.criterion_2 + payload.criterion_3) / 3;
        }
      }

      if (payload.overall === undefined || Number.isNaN(payload.overall)) {
        alert('Δώσε έγκυρο συνολικό βαθμό.');
        return;
      }

      await API.grades.saveMine(thesisId, payload);

      bootstrap.Modal.getOrCreateInstance(wrap).hide();
      await refreshGradesList(thesisId, hostEl);
      alert('Ο βαθμός αποθηκεύτηκε.');
    } catch (e) {
      console.error('[grades] save failed', e);
      alert(e?.message || 'Αποτυχία αποθήκευσης βαθμού');
    }
  });

  // άνοιγμα modal
  bootstrap.Modal.getOrCreateInstance(wrap).show();
}




/* ---- Hook στο section router σου ---- */
(() => {
  const orig = window.didReloadSection;
  window.didReloadSection = (id) => {
    if (orig) orig(id);
    if (id === 'section-diaxeirisi') loadManageTheses();
  };
})();

/* ---- SAFE hooks για να μη “ξεφεύγει” το loadManageTheses ---- */
(() => {
  const oldDidLoad = window.didLoad || (() => {});
  window.didLoad = () => {
    try { oldDidLoad(); } catch {}
    // Αν υπάρχει το section στη σελίδα, φόρτωσέ το (ακόμα κι αν δεν είναι ορατό)
    if (document.getElementById('manageThesesList')) {
      setTimeout(loadManageTheses, 0);
    }
  };

  const oldDidReload = window.didReloadSection || (() => {});
  window.didReloadSection = (id) => {
    try { oldDidReload(id); } catch {}
    // Δεν βασιζόμαστε στο id, αλλά στην ύπαρξη του container
    if (document.getElementById('manageThesesList')) {
      setTimeout(loadManageTheses, 0);
    }
  };

  // Αν ήρθαμε εδώ και το section υπάρχει ήδη (π.χ. άνοιγμα σε anchor), δοκίμασε να φορτώσεις
  if (document.getElementById('manageThesesList')) {
    setTimeout(loadManageTheses, 0);
  }
})();



/* ---------- Hooks από dashboard ---------- */
window.didLoad = () => {
  // ανοίγει στο Θεματολόγιο
  loadTopics();
  createTopic();
};

window.didReloadSection = (id) => {
  if (id === 'section-themata')     loadTopics();
  if (id === 'section-anathesi')    initAssign();        // <-- σωστό id
  if (id === 'section-proskliseis') loadInvitations();
  if (id === 'section-diplomatikes') loadMyTheses();
  if (id === 'section-statistika')    loadFacultyStats();
};
