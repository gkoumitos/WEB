(() => {
  const $ = (sel, ctx=document) => ctx.querySelector(sel);
  const $$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));
  const on = (el, ev, fn) => el && el.addEventListener(ev, fn);

  // ===== SECTION NAVIGATION =====
  function initSections(){
    const sections = $$('[data-section]');
    const navBtns = $$('[data-target]');

    function showSection(id){
      sections.forEach(sec => {
        sec.classList.toggle('d-none', sec.getAttribute('data-section') !== id);
      });
      navBtns.forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-target') === id);
      });
      localStorage.setItem('gram-active-section', id);
    }

    // Default: first section visible
    const saved = localStorage.getItem('gram-active-section');
    const first = sections[0]?.getAttribute('data-section');
    if (sections.length){
      showSection(saved || first);
    }

    navBtns.forEach(btn => on(btn, 'click', (e) => {
      e.preventDefault();
      const id = btn.getAttribute('data-target');
      if (id) showSection(id);
    }));
  }

  // ===== TABLE UTILITIES =====
  function enhanceTables(){
    const tables = $$('.data-table');
    tables.forEach(tbl => makeTableInteractive(tbl));
  }

  function makeTableInteractive(table){
    const perPage = Number(table.dataset.pageSize || 10);
    const tbody = $('tbody', table);
    if (!tbody) return;

    const rows = Array.from(tbody.rows);
    const header = $('thead', table);
    const container = table.parentElement;

    // Search box
    const searchWrap = document.createElement('div');
    searchWrap.className = 'd-flex align-items-center justify-content-between mb-2 gap-2 flex-wrap';
    searchWrap.innerHTML = `
      <input type="search" class="form-control" placeholder="Αναζήτηση..." style="max-width: 280px">
      <div class="ms-auto small text-muted" data-role="pager-info"></div>
    `;
    container.insertBefore(searchWrap, table);
    const searchInput = $('input[type="search"]', searchWrap);
    const pagerInfo = $('[data-role="pager-info"]', searchWrap);

    // Pagination
    const pager = document.createElement('nav');
    pager.className = 'mt-2';
    container.appendChild(pager);

    let view = rows.slice();
    let page = 1;
    let sortIdx = -1;
    let sortDir = 1;

    function applyFilter(){
      const q = (searchInput.value || '').trim().toLowerCase();
      view = rows.filter(tr => tr.innerText.toLowerCase().includes(q));
      if (sortIdx >= 0){
        view.sort((a,b) => cmp(a.cells[sortIdx]?.innerText, b.cells[sortIdx]?.innerText) * sortDir);
      }
      page = 1;
      render();
    }

    function cmp(a,b){
      const na = parseFloat(a); const nb = parseFloat(b);
      if (!Number.isNaN(na) && !Number.isNaN(nb)) return na-nb;
      return String(a).localeCompare(String(b), 'el', { sensitivity: 'base', numeric: true });
    }

    function render(){
      const total = view.length;
      const pages = Math.max(1, Math.ceil(total / perPage));
      const start = (page-1)*perPage;
      const end = start + perPage;
      tbody.replaceChildren(...view.slice(start, end));
      pagerInfo.textContent = total ? `Εμφάνιση ${start+1}–${Math.min(end,total)} από ${total}` : 'Δεν βρέθηκαν εγγραφές';

      // Build pager
      const items = [];
      function li(disabled, active, label, targetPage){
        const li = document.createElement('li');
        li.className = `page-item${disabled?' disabled':''}${active?' active':''}`;
        li.innerHTML = `<a class="page-link" href="#">${label}</a>`;
        on(li, 'click', (e)=>{
          e.preventDefault();
          if (disabled) return;
          page = targetPage;
          render();
        });
        return li;
      }
      const ul = document.createElement('ul');
      ul.className = 'pagination pagination-sm';
      ul.append(
        li(page===1,false,'«',1),
        li(page===1,false,'‹',Math.max(1,page-1)),
      );
      const windowSize = 5;
      const startPage = Math.max(1, page - Math.floor(windowSize/2));
      const endPage = Math.min(pages, startPage + windowSize - 1);
      for (let p=startPage; p<=endPage; p++){
        ul.append(li(false, p===page, String(p), p));
      }
      ul.append(
        li(page===pages,false,'›',Math.min(pages,page+1)),
        li(page===pages,false,'»',pages),
      );
      pager.replaceChildren(ul);
    }

    // Sorting on header click
    if (header){
      const ths = Array.from(header.querySelectorAll('th'));
      ths.forEach((th, idx) => {
        th.style.cursor = 'pointer';
        th.title = 'Ταξινόμηση';
        on(th, 'click', () => {
          if (sortIdx === idx){
            sortDir *= -1;
          } else {
            sortIdx = idx;
            sortDir = 1;
          }
          applyFilter();
        });
      });
    }

    on(searchInput, 'input', applyFilter);
    applyFilter();
  }

  // ===== STATS (optional) =====
  async function fillStats(){
    const elStudents = $('#stats-students');
    const elFaculty  = $('#stats-faculty');
    const elTheses   = $('#stats-theses');
    if (!elStudents && !elFaculty && !elTheses) return;

    async function tryFetch(url){
      try {
        const res = await fetch(url, { headers: { 'Accept':'application/json' }});
        if (!res.ok) throw new Error('HTTP '+res.status);
        return await res.json();
      } catch(e) { return null; }
    }

    // Try a generic /api/stats
    const stats = await tryFetch('/api/stats');
    if (stats){
      if (elStudents && stats.students != null) elStudents.textContent = stats.students;
      if (elFaculty  && stats.faculty  != null) elFaculty.textContent  = stats.faculty;
      if (elTheses   && stats.theses   != null) elTheses.textContent   = stats.theses;
      return;
    }

    // Fallback: count from tables if present
    if (elStudents){
      const t = document.querySelector('[data-section="students"] .data-table tbody');
      if (t) elStudents.textContent = t.rows.length;
    }
    if (elFaculty){
      const t = document.querySelector('[data-section="faculty"] .data-table tbody');
      if (t) elFaculty.textContent = t.rows.length;
    }
    if (elTheses){
      const t = document.querySelector('[data-section="theses"] .data-table tbody');
      if (t) elTheses.textContent = t.rows.length;
    }
  }

  // ===== LOGOUT button wiring (if present) =====
  function wireLogout(){
    const btn = $('#logoutBtn, [data-action="logout"]');
    if (!btn) return;
    on(btn, 'click', (e) => {
      e.preventDefault();
      try {
        if (window.logout) window.logout();
        else {
          localStorage.removeItem('jwt');
          location.href = '../index.html';
        }
      } catch(_){
        localStorage.removeItem('jwt');
        location.href = '../index.html';
      }
    });
  }

  // ===== Bootstrap toast helper =====
  function toast(msg){
    const area = $('#toastArea') || (()=>{
      const d = document.createElement('div');
      d.id = 'toastArea';
      d.className = 'toast-container position-fixed bottom-0 end-0 p-3';
      document.body.appendChild(d);
      return d;
    })();
    const wrapper = document.createElement('div');
    wrapper.className = 'toast';
    wrapper.innerHTML = `
      <div class="toast-header">
        <strong class="me-auto">Ενημέρωση</strong>
        <small>τώρα</small>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
      <div class="toast-body">${msg}</div>
    `;
    area.appendChild(wrapper);
    // Bootstrap 5 toast
    try {
      const Toast = bootstrap.Toast;
      const t = new Toast(wrapper, { delay: 2500 });
      t.show();
    } catch(_){
      // fallback
      wrapper.style.display = 'block';
      setTimeout(() => wrapper.remove(), 2500);
    }
  }

  // ===== INIT =====
  document.addEventListener('DOMContentLoaded', () => {
    initSections();
    enhanceTables();
    fillStats();
    wireLogout();
    // Expose helper
    window.gramToast = toast;
  });
})();
