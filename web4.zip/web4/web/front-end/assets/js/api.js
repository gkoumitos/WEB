// front-end/assets/js/api.js
const API_BASE = (window.API_BASE)
  ? window.API_BASE
  : (location.hostname ? `http://${location.hostname}:3000` : 'http://localhost:3000');

let TOKEN = localStorage.getItem('jwt');

export function setToken(t){ TOKEN = t; localStorage.setItem('jwt', t); }
export function clearToken(){ TOKEN = null; localStorage.removeItem('jwt'); }

async function req(path, opts = {}){
  const headers = { ...(opts.headers || {}) };
  if (!(opts.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;

  const res = await fetch(API_BASE + path, { ...opts, headers });

  if (res.status === 204) return null;

  let data = null;
  try { data = await res.json(); } catch (_) {}

  if (!res.ok) {
    const msg = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

export const API = {
  login: (email, password) => req('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  }),

  import: {
    users: async (users) => {
      // Δέχεσαι είτε [{...}, {...}] είτε { users:[...] } (για συμβατότητα)
      const payload = Array.isArray(users) ? { users } : users;

      // 1η προσπάθεια: { users:[...] }
      let r = await fetch(API_BASE + '/api/import/users', {
        method: 'POST',
        headers: TOKEN ? { 'Authorization': 'Bearer ' + TOKEN, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      // Fallback: αν ο server περιμένει κατευθείαν [] (παλαιότερη εκδοχή)
      if (!r.ok && r.status === 400) {
        r = await fetch(API_BASE + '/api/import/users', {
          method: 'POST',
          headers: TOKEN ? { 'Authorization': 'Bearer ' + TOKEN, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' },
          body: JSON.stringify(Array.isArray(users) ? users : (users?.users || []))
        });
      }

      if (!r.ok) throw new Error(await r.text());
      return r.json(); // π.χ. { inserted: N }
    }
  },

  auth: {
    login: (email, password) => API.login(email, password),
    me: () => req('/api/auth/me'),
    logout: async () => { clearToken(); }
  },

    users: {
      me:      () => req('/api/users/me'),
      update:  (payload) => req('/api/users/me', {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),
      searchStudents: (q) => req(`/api/users/search?role=student&q=${encodeURIComponent(q||'')}`),
      getByCode: (code) => req(`/api/users/by-code/${encodeURIComponent(code)}`)
  },
    
    faculty: {
    list: ({ q, thesis_id } = {}) => {
      const qs = new URLSearchParams();
      if (q) qs.set('q', q);
      if (thesis_id) qs.set('thesis_id', thesis_id);
      return req('/api/faculty' + (qs.toString() ? `?${qs.toString()}` : ''));
    }
  },

    files: {
      uploadFile: async (file) => {
        const fd = new FormData();
        fd.append('file', file);
        const r = await fetch(API_BASE + '/api/files/upload', {
          method: 'POST',
          headers: TOKEN ? { 'Authorization': 'Bearer ' + TOKEN } : {},
          body: fd
        });
        if (!r.ok) throw new Error(await r.text());
        return r.json(); // { url, originalName, size, mime }
      },

      // (προαιρετικά) συμβατότητα αν κάπου στέλνεις έτοιμο FormData
      upload: async (formData) => {
        const r = await fetch(API_BASE + '/api/files/upload', {
          method: 'POST',
          headers: TOKEN ? { 'Authorization': 'Bearer ' + TOKEN } : {},
          body: formData
        });
        if (!r.ok) throw new Error(await r.text());
        return r.json(); // { url, ... }
      }
    },


  
    topics: {
      mine:    () => req('/api/topics/'),
      listMine:() => req('/api/topics/'), // alias

      create:  (payload) => req('/api/topics/', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

      update:  (id, payload) => req(`/api/topics/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),
    },

    invitations: {
      mine: () => req('/api/invitations/mine'),
      create: (a,b) => {
        const payload = (typeof a === 'object' && a) ? a : { thesis_id: a, faculty_id: b };
        return req('/api/invitations', { method: 'POST', body: JSON.stringify(payload) });
      },
      accept:  (id) => req(`/api/invitations/${id}/accept`,  { method: 'POST' }),
      decline: (id) => req(`/api/invitations/${id}/decline`, { method: 'POST' }),
    },

    theses: {
      mine: () => req('/api/theses/mine'),
      completedSupervised: () => req('/api/theses/completed/supervised'),
      underReviewSupervised: () => req('/api/theses/under-review/supervised'),
      create: (payload) => req('/api/theses', {           // { topic_id, student_id, pdf? }
        method: 'POST',
        body: JSON.stringify(payload)
      }),
      changeStatus: (id, status) => req(`/api/theses/${id}/status`, {
        method: 'POST',
        body: JSON.stringify({ status })
      }),
      draft: (id, path) => req(`/api/theses/${id}/draft`, {
        method: 'POST',
        body: JSON.stringify({ path })
      }),
      getDraft: (id) => req(`/api/theses/${id}/draft`),
      addLink: (id, payload) => {
        const body = (typeof payload === 'string') ? { url: payload } : payload;
        return req(`/api/theses/${id}/links`, {
          method: 'POST',
          body: JSON.stringify(body)
        });
      },
      getForStudent: (id) => req(`/api/theses/${id}/mine`),
      listLinks: (id) => req(`/api/theses/${id}/links`),
      setRepository: (id, repository_url) => req(`/api/theses/${id}/repository`, {
        method: 'POST',
        body: JSON.stringify({ repository_url })
      }),
      setReview: (id, payload) => req(`/api/theses/${id}/review`, {
        method: 'POST',
        body: JSON.stringify(payload) // { review_date, review_location }
      }),
      list: ({ status = [], q = '', limit = 50, offset = 0 } = {}) => {
    const qs = new URLSearchParams();
    if (status.length) qs.set('status', status.join(','));
    if (q) qs.set('q', q);
    qs.set('limit', limit); qs.set('offset', offset);
    return req(`/api/theses?${qs.toString()}`);
  },
  get: (id) => req(`/api/theses/${id}`),
      // --- Secretariat actions ---
gs: (id, { decision_no /*, decision_year*/ }) =>
  req(`/api/theses/${id}/gs`, {
    method: 'POST',
    body: JSON.stringify({ decision_no /*, decision_year*/ })
  }),

cancel: (id, { reason, gs_number, gs_year }) =>
  req(`/api/theses/${id}/cancel`, {
    method: 'POST',
    body: JSON.stringify({ reason, gs_number, gs_year })
  }),

complete: (id) =>
  req(`/api/theses/${id}/complete`, { method: 'POST' }),

    },
    stats: {
      // { avg_days_supervisor, avg_grade_supervisor, total_supervised,
      //   avg_days_member,     avg_grade_member,     total_member }
      mine: () => req('/api/stats/mine')
    },

    notes: {
      mine:   (thesis_id) => req(`/api/notes/${thesis_id}/mine`),
      create: (thesis_id, text) => req('/api/notes', { method:'POST', body: JSON.stringify({ thesis_id, text }) }),
      remove: (note_id)  => req(`/api/notes/${note_id}`, { method:'DELETE' })
    },

    // --- GRADES -------------------------------------------------
    grades: {
      // όλοι οι βαθμοί μιας διπλωματικής
      list: (thesisId) => req(`/api/grades/${thesisId}`),

      mine: (thesisId) => req(`/api/grades/${thesisId}/mine`),

      saveMine: (thesisId, payload) => req(`/api/grades/${thesisId}/mine`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
      get: (id) => req(`/api/theses/${id}`),
list: ({ status = [] } = {}) => {
  const qs = new URLSearchParams();
  if (status.length) qs.set('status', status.join(','));
  return req(`/api/theses?${qs.toString()}`);
},

    },

    // th


// announcements:
announcements: {
  create: (payload) => req('/feed/announcements', {
    method: 'POST',
    body: JSON.stringify(payload)
  }),
  list: ({from, to} = {}) => {
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to)   qs.set('to', to);
    return req('/feed/announcements' + (qs.toString()?`?${qs}`:''));
  }
},
}



  