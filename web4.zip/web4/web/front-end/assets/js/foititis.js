import { API } from './api.js';

async function loadMyThesis(){
const data = await API.theses.mine();
const container = document.getElementById('myThesis');
if (!data.length) return container.innerHTML = '<em>Δεν έχει ανατεθεί διπλωματική.</em>';
const t = data[0];
container.innerHTML = `<h5>${t.title}</h5><span class="badge bg-info">${t.status}</span>`;
}

// foititis.js
async function inviteMember(){
  const f = document.getElementById('inviteForm');
  f?.addEventListener('submit', async (e)=>{
    e.preventDefault();

    const thesis_id  = Number(f.thesis_id.value);
    const faculty_id = Number(f.faculty_id.value);

    await API.invitations.create({ thesis_id, faculty_id });
    alert('Πρόσκληση στάλθηκε');
  });
}


import { API } from './api.js';

async function uploadDraft(){
  const f = document.getElementById('draftForm');
  f?.addEventListener('submit', async (e)=>{
    e.preventDefault();

    const file = f.draft.files[0];
    if (!file) return alert('Επίλεξε αρχείο');

    // 1) Upload αρχείου
    const up = await API.files.uploadFile(file); // -> { url }

    // 2) Δήλωση draft στη διπλωματική
    await API.theses.draft(Number(f.thesis_id.value), up.url);

    // 3) Εμφάνιση συνδέσμου στο UI
    document.getElementById('draftLink').innerHTML =
      `<a href="${up.url}" target="_blank" rel="noopener">Πρόχειρο</a>`;

    alert('Το πρόχειρο ανέβηκε και δηλώθηκε στη διπλωματική.');
  });
}

async function uploadExternalLink(){
  const f = document.getElementById('linkForm');
  f?.addEventListener('submit', async (e)=>{
    e.preventDefault();

    const url = f.url.value.trim();
    if (!url) return alert('Συμπλήρωσε σύνδεσμο');
    const label = f.label.value.trim();

    await API.theses.addLink(Number(f.thesis_id.value), { url, label });
    alert('Ο σύνδεσμος αποθηκεύτηκε.');

    // μπορείς να κάνεις και refresh τη λίστα links
  });
}


window.foitLoad = () => { loadMyThesis(); inviteMember(); uploadDraft(); };

import { API } from './api.js';

function statusLabel(s){
  switch (s) {
    case 'proposed':     return 'Υπό Ανάθεση';
    case 'active':       return 'Ενεργή';
    case 'under_review': return 'Υπό Εξέταση';
    case 'completed':    return 'Περατωμένη';
    case 'cancelled':    return 'Ακυρωμένη';
    default:             return s || '-';
  }
}

export async function renderStudentThesisPage() {
  const c = document.getElementById('thema');
  try {
    const rows = await API.theses.mine();
    if (!rows || !rows.length) {
      c.innerHTML = `<div class="alert alert-info">Δεν έχει ανατεθεί διπλωματική.</div>`;
      return;
    }
    const t = rows[0];

    const started = t.started_at ? new Date(t.started_at) : null;
    const elapsedDays = started ? Math.floor((Date.now() - started.getTime()) / (1000*60*60*24)) : null;

    c.innerHTML = `
      <h2 class="mb-4">📄 Πληροφορίες Θέματος Διπλωματικής</h2>
      <div class="mb-4">
        <h4>Τίτλος:</h4>
        <p>${t.title || '-'}</p>
        <h4>Περιγραφή:</h4>
        <p>${t.summary ? t.summary : '<em>—</em>'}</p>
        <h4>Αρχείο Περιγραφής:</h4>
        ${t.pdf ? `<button id="pdfBtn" class="btn btn-outline-primary btn-sm">Προβολή αρχείου PDF</button>` :
                   `<span class="text-muted">Δεν υπάρχει PDF</span>`}
      </div>
      <div class="mb-4">
        <h4>Κατάσταση:</h4>
        <span class="badge ${t.status === 'active' ? 'bg-success' :
                              t.status === 'proposed' ? 'bg-warning text-dark' :
                              t.status === 'under_review' ? 'bg-info' :
                              t.status === 'completed' ? 'bg-secondary' : 'bg-dark'}">
          ${statusLabel(t.status)}
        </span>
      </div>
      <div class="mb-4">
        <h4>Ημερομηνία Ανάθεσης:</h4>
        <p>${started ? started.toLocaleDateString('el-GR') : '—'}</p>
        ${elapsedDays != null ? `<p><em>Πέρασαν: ${elapsedDays} ημέρες</em></p>` : ''}
      </div>
    `;

    if (t.pdf) {
      document.getElementById('pdfBtn').addEventListener('click', () => {
        window.open(t.pdf, '_blank', 'noopener');
      });
    }
  } catch (err) {
    console.error(err);
    c.innerHTML = `<div class="alert alert-danger">Αποτυχία φόρτωσης δεδομένων.</div>`;
  }
}
