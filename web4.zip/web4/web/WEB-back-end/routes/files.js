const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const filesController = require('../controllers/filesController');

router.post('/upload', authenticate, filesController.uploadFile);

module.exports = router;
