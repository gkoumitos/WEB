const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/thesesController');
const { authenticate, authorize } = require('../middleware/auth');
const theses = require('../controllers/thesesController');

// Διδάσκων: αρχική ανάθεση
router.post('/', authenticate, authorize('faculty'), ctrl.assignToStudent);

// Προβολή ανά χρήστη
router.get('/mine', authenticate, ctrl.listMine);

// Αλλαγές κατάστασης
router.post('/:id/status', authenticate, ctrl.changeStatus);

// --- Student actions (review, draft, links, repository) ---
router.post('/:id/review', authenticate, ctrl.setReviewInfo);           // Υπό Εξέταση: δήλωση ημερομηνίας/χώρου/συνδέσμου
router.post('/:id/draft', authenticate, ctrl.attachDraftFile);          // upload μέσω /files/upload -> δίνουμε σχετική διαδρομή
router.post('/:id/links', authenticate, ctrl.addLink);                  // προσθήκη επιπλέον URL
router.get('/:id/links', authenticate, ctrl.listLinks);                 // λίστα URLs
router.post('/:id/repository', authenticate, ctrl.setRepositoryUrl);    // σύνδεσμος Νημερτής

// --- Secretariat actions ---
router.post('/:id/gs', authenticate, authorize('secretariat'), ctrl.setGSDecision);        // καταχώρηση ΑΠ ΓΣ
router.post('/:id/cancel', authenticate, authorize('secretariat','faculty'), ctrl.cancel);  // ακύρωση ανάθεσης (με λόγο)

// --- Complete / Practical (HTML) ---
router.post('/:id/complete', authenticate, authorize('secretariat'), ctrl.completeIfEligible); // Περατωμένη
router.get('/:id/praktiko', authenticate, ctrl.praktikoHtml);                                   // HTML πρακτικό

// --- Export (CSV/JSON) για διδάσκοντα (λίστα διπλωματικών) ---
router.get('/export/mine', authenticate, authorize('faculty'), ctrl.exportMine);

// --- Student actions (review, draft, links, repository) ---
router.post('/:id/review', authenticate, authorize('student'), ctrl.setReviewInfo);

router.post('/', authenticate, authorize('faculty'), theses.create);
// …τα υπόλοιπα routes σου (mine, changeStatus, draft, κλπ)

router.get('/', authenticate, authorize('secretariat'), ctrl.listAll);
router.get('/:id', authenticate, authorize('secretariat'), ctrl.getOne);

// Προβολή πλήρων στοιχείων ΔΕ από τον ΙΔΙΟ φοιτητή (safe & backwards-compatible)
router.get('/:id/mine', authenticate, authorize('student'), ctrl.getOne);


router.get('/:id/eligibility', authenticate, ctrl.eligibility);
module.exports = router;

router.get('/completed/supervised', authenticate, authorize('faculty'), ctrl.listCompletedSupervised);

router.get('/under-review/supervised',
  authenticate, authorize('faculty'),
  ctrl.listUnderReviewSupervised
);

router.get(
  '/under-review/supervised',
  authenticate,
  authorize('faculty'),
  ctrl.listUnderReviewSupervised
);
