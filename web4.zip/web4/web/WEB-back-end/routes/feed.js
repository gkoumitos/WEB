const express = require('express');
const fs = require('fs');
const path = require('path');
const db = require('../db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
const DATA_DIR  = path.join(__dirname, '..', 'data');
const FEED_FILE = path.join(DATA_DIR, 'announcements.json');
if (!fs.existsSync(DATA_DIR))  fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(FEED_FILE)) fs.writeFileSync(FEED_FILE, '[]', 'utf8');

// GET /feed/announcements?from=YYYY-MM-DD&to=YYYY-MM-DD
router.get('/announcements', async (req, res, next) => {
  try {
    const all = JSON.parse(fs.readFileSync(FEED_FILE, 'utf8'));
    const from = req.query.from ? new Date(req.query.from) : null;
    const to   = req.query.to   ? new Date(req.query.to)   : null;
    const filtered = all.filter(a => {
      const d = a.scheduled_at ? new Date(a.scheduled_at) : null;
      if (!d) return true;
      if (from && d < from) return false;
      if (to   && d > to)   return false;
      return true;
    });
    res.json(filtered.sort((a,b)=>new Date(a.scheduled_at||a.created_at)-new Date(b.scheduled_at||b.created_at)));
  } catch (e) { next(e); }
});

// POST /feed/announcements  (μόνο faculty, μόνο supervisor, μόνο αν thesis.completed)
router.post('/announcements', authenticate, authorize('faculty'), async (req, res, next) => {
  try {
    const { thesis_id, title, body, scheduled_at, room } = req.body || {};
    if (!thesis_id) return res.status(400).json({ error: 'Missing thesis_id' });

    const [[t]] = await db.query(
      `SELECT t.id, t.status, t.supervisor_id,
              tp.title AS thesis_title, tp.summary AS thesis_summary,
              s.first_name AS s_fn, s.last_name AS s_ln, s.email AS s_email,
              t.repository_url, t.review_date, t.review_location
       FROM theses t
       JOIN thesis_topics tp ON tp.id=t.topic_id
       JOIN users s ON s.id=t.student_id
       WHERE t.id=?`, [thesis_id]
    );
    if (!t) return res.status(404).json({ error: 'Thesis not found' });
    if (t.supervisor_id !== req.user.id) return res.status(403).json({ error: 'Not supervisor' });
    if (t.status !== 'completed')       return res.status(400).json({ error: 'Thesis must be completed' });

    const [links] = await db.query('SELECT url, label FROM thesis_links WHERE thesis_id=? ORDER BY id DESC', [thesis_id]);

// ΑΥΣΤΗΡΑ μόνο "under review" (και ελληνικά ισοδύναμα)
const norm = (th.status || '').trim().toLowerCase();
const allowed = ['under_review','υπό εξέταση','υπο εξεταση'];
if (!allowed.includes(norm)) {
  return res.status(400).json({ error: 'Thesis must be under review' });
}


    const item = {
      id: Date.now(),
      thesis_id,
      title: title || t.thesis_title,
      body:  body  || t.thesis_summary,
      student_name: `${t.s_ln} ${t.s_fn}`,
      student_email: t.s_email,
      repository_url: t.repository_url || null,
      links: (links||[]).map(l=>({ url:l.url, label:l.label||null })),
      scheduled_at: scheduled_at || t.review_date || null,
      room: room || t.review_location || null,
      created_by: req.user.id,
      created_at: new Date().toISOString()
    };

    const all = JSON.parse(fs.readFileSync(FEED_FILE, 'utf8'));
    all.push(item);
    fs.writeFileSync(FEED_FILE, JSON.stringify(all, null, 2), 'utf8');

    res.status(201).json({ ok:true, id:item.id });
  } catch (e) { next(e); }
});

module.exports = router;
