const db = require('../db');
const { required } = require('../middleware/validate');

// GET /api/users/me
exports.getMe = async (req, res, next) => {
  try {
    const [[u]] = await db.query(
      `SELECT id, role, first_name, last_name, email,
              address, phone_mobile, phone_landline
       FROM users WHERE id = ?`,
      [req.user.id]
    );
    if (!u) return res.status(404).json({ error: 'User not found' });
    res.json(u);
  } catch (e) { next(e); }
};

// PUT /api/users/me
exports.updateMe = async (req, res, next) => {
  try {
    const { email, address, phone_mobile, phone_landline } = req.body || {};

    // basic validation (μπορείς να το σφίξεις αργότερα)
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email' });
    }

    await db.query(
      `UPDATE users
         SET email = COALESCE(?, email),
             address = COALESCE(?, address),
             phone_mobile = COALESCE(?, phone_mobile),
             phone_landline = COALESCE(?, phone_landline)
       WHERE id = ?`,
      [email, address, phone_mobile, phone_landline, req.user.id]
    );

    // επιστρέφουμε τα νέα δεδομένα
    const [[u]] = await db.query(
      `SELECT id, role, first_name, last_name, email,
              address, phone_mobile, phone_landline
       FROM users WHERE id = ?`,
      [req.user.id]
    );
    res.json(u);
  } catch (e) { next(e); }
};

exports.search = async (req, res) => {
  try {
    const role = req.query.role || 'student';
    const q = (req.query.q || '').trim();
    const like = `%${q}%`;

    const [rows] = await db.query(
      `SELECT id, first_name, last_name, email, am
       FROM users
       WHERE role = ?
         AND (am LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)
       ORDER BY last_name ASC LIMIT 10`,
      [role, like, like, like, like]
    );
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.searchStudents = async (req, res) => {
  try {
    const q = req.query.q?.trim();
    if (!q) return res.json([]);

    // Ψάχνουμε σε am (αριθμό μητρώου) ή first_name/last_name
    const [rows] = await db.query(
      `SELECT id, first_name, last_name, email 
       FROM users 
       WHERE role='student' 
         AND (first_name LIKE ? OR last_name LIKE ?) 
       LIMIT 10`,
      [`%${q}%`, `%${q}%`, `%${q}%`]
    );

    res.json(rows);
  } catch (err) {
    console.error('[usersController.searchStudents]', err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.getByCode = async (req, res) => {
  const code = String(req.params.code || '').toUpperCase();

  // Βασικός έλεγχος (A + digits)
  if (!/^A\d+$/.test(code)) {
    return res.status(400).json({ error: 'Ο κωδικός δεν είναι έγκυρος ΑΜ φοιτητή.' });
  }

  try {
    const [rows] = await db.query(
      `SELECT id, first_name, last_name, email, user_code
       FROM users
       WHERE role = 'student' AND user_code = ?
       LIMIT 1`,
      [code]
    );

    if (!rows.length) {
      return res.status(404).json({ error: 'Δεν βρέθηκε φοιτητής με αυτόν τον ΑΜ.' });
    }

    return res.json(rows[0]);
  } catch (err) {
    console.error('getByCode error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
};