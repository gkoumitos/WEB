const db = require('../db');

// GET /api/faculty?q=...&thesis_id=123
exports.list = async (req, res, next) => {
  try {
    const { q, thesis_id } = req.query;
    const params = [];
    const where = ["u.role='faculty'"];

    if (q) {
      const like = `%${q}%`;
      where.push(`(u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?)`);
      params.push(like, like, like);
    }

    if (thesis_id) {
      // μην εμφανίζεις τον επιβλέποντα της συγκεκριμένης διπλωματικής
      where.push(`u.id NOT IN (SELECT COALESCE(supervisor_id,-1) FROM theses WHERE id = ?)`);
      params.push(thesis_id);
      // μην εμφανίζεις όσους είναι ήδη στην τριμελή (οποιασδήποτε κατάστασης)
      where.push(`u.id NOT IN (SELECT cm.faculty_id FROM committee_members cm WHERE cm.thesis_id = ?)`);
      params.push(thesis_id);
    }

    const sql = `
      SELECT u.id, u.first_name, u.last_name, u.email
      FROM users u
      WHERE ${where.join(' AND ')}
      ORDER BY u.last_name, u.first_name
      LIMIT 200
    `;
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) { next(e); }
};
