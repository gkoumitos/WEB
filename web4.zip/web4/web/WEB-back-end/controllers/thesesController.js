const db = require('../db');
const { required } = require('../middleware/validate');

exports.assignToStudent = async (req, res, next) => {
  try {
    required(req.body, ['topic_id', 'student_id']);
    const { topic_id, student_id } = req.body;

    const [r] = await db.query(
      'INSERT INTO theses (topic_id, student_id, supervisor_id, status, started_at) VALUES (?,?,?,?,CURDATE())',
      [topic_id, student_id, req.user.id, 'proposed']
    );
    const thesisId = r.insertId;

    await db.query(
      'INSERT INTO status_history (thesis_id, from_status, to_status, changed_by) VALUES (?,?,?,?)',
      [thesisId, null, 'proposed', req.user.id]
    );

    res.status(201).json({ id: thesisId });
  } catch (e) { next(e); }
};

// GET /api/theses/mine
exports.listMine = async (req, res, next) => {
  try {
    let whereSql = '';
    let params = [];

    if (req.user.role === 'student') {
      whereSql = 't.student_id = ?';
      params = [req.user.id];
    } else if (req.user.role === 'faculty') {
      whereSql = '(t.supervisor_id = ? OR EXISTS (SELECT 1 FROM committee_members cm WHERE cm.thesis_id = t.id AND cm.faculty_id = ?))';
      params = [req.user.id, req.user.id];
    } else if (req.user.role === 'secretariat') {
      whereSql = '1=1';
    } else {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const [rows] = await db.query(`
      SELECT
        t.id,
        t.status,
        DATE_FORMAT(t.started_at, '%Y-%m-%d')            AS started_at,
        DATE_FORMAT(t.completed_at, '%Y-%m-%d')          AS completed_at,
        DATE_FORMAT(t.review_date, '%Y-%m-%d %H:%i:%s')  AS review_date,
        t.review_location,

        t.repository_url,                                        -- NEW: να το βλέπει η Γραμματεία/UI

        /* NEW: aggregates για την ύπαρξη βαθμών */
        (SELECT ROUND(AVG(g.overall),2)
          FROM grades g
        WHERE g.thesis_id = t.id)                      AS avg_grade,
        (SELECT COUNT(DISTINCT g.grader_id)
          FROM grades g
        WHERE g.thesis_id = t.id)                      AS graders_count,

        tp.title,
        tp.summary,
        tp.description_file                               AS pdf,

        s.id         AS student_id,
        s.first_name AS student_first_name,
        s.last_name  AS student_last_name,

        sup.id         AS supervisor_id,
        sup.first_name AS supervisor_first_name,
        sup.last_name  AS supervisor_last_name
      FROM theses t
      JOIN thesis_topics tp ON tp.id = t.topic_id
      JOIN users s          ON s.id  = t.student_id
      LEFT JOIN users sup   ON sup.id = t.supervisor_id
      WHERE ${whereSql}
      ORDER BY t.id DESC
    `, params);

    res.json(rows);
  } catch (e) { next(e); }
};

exports.changeStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    // Δέξου και status και to_status
    const wanted = req.body?.status ?? req.body?.to_status;
    if (!wanted) return res.status(400).json({ error: 'Missing field: status' });

    const [[t]] = await db.query(
      'SELECT student_id, supervisor_id, status FROM theses WHERE id=?',
      [id]
    );

    const isStudent    = (req.user.role === 'student'  && req.user.id === t.student_id);
    const isSupervisor = (req.user.role === 'faculty'  && req.user.id === t.supervisor_id);
    if (!(isStudent || isSupervisor)) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    // επιτρέπουμε μόνο active -> under_review
    if (!(t.status === 'active' && wanted === 'under_review')) {
      return res.status(400).json({ error: 'Invalid transition' });
    }

    await db.query('UPDATE theses SET status=? WHERE id=?', [wanted, id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

const { create } = require('xmlbuilder2'); // για HTML πρακτικού – θα φτιάξουμε απλό string

// --- Student: δήλωση ημερομηνίας/χώρου/συνδέσμου εξέτασης ---
exports.setReviewInfo = async (req, res, next) => {
  try {
    const { id } = req.params;
    // επιτρέπουμε μόνο στον φοιτητή της συγκεκριμένης διπλωματικής
    const [[th]] = await db.query('SELECT student_id FROM theses WHERE id=?', [id]);
    if (!th) return res.status(404).json({ error: 'Thesis not found' });
    if (th.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

    const { review_date, review_location } = req.body || {};
    await db.query(
      `UPDATE theses
         SET review_date = ?, review_location = ?
       WHERE id = ?`,
      [review_date || null, review_location || null, id]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
};


// --- Student: καταχώρηση draft file (λαμβάνει relative path από /files/upload) ---
exports.attachDraftFile = async (req, res, next) => {
  try {
    const { id } = req.params;
    required(req.body, ['path']);
    const { path } = req.body;
    const [[t]] = await db.query('SELECT student_id FROM theses WHERE id=?', [id]);
    if (!t) return res.status(404).json({ error: 'Not found' });
    if (t.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
    await db.query('UPDATE theses SET draft_file=? WHERE id=?', [path, id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

// --- Student: προσθήκη/λίστα URLs πρόσθετου υλικού ---
exports.addLink = async (req, res, next) => {
  try {
    const { id } = req.params;
    required(req.body, ['url']);
    const { url, label } = req.body;
    const [[t]] = await db.query('SELECT student_id FROM theses WHERE id=?', [id]);
    if (!t) return res.status(404).json({ error: 'Not found' });
    if (t.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
    const [r] = await db.query('INSERT INTO thesis_links (thesis_id, url, label) VALUES (?,?,?)', [id, url, label || null]);
    res.status(201).json({ id: r.insertId });
  } catch (e) { next(e); }
};

exports.listLinks = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query('SELECT id, url, label, created_at FROM thesis_links WHERE thesis_id=? ORDER BY id DESC', [id]);
    res.json(rows);
  } catch (e) { next(e); }
};

// --- Student: δήλωση συνδέσμου Νημερτής (repository) ---
exports.setRepositoryUrl = async (req, res, next) => {
  try {
    const { id } = req.params;
    required(req.body, ['repository_url']);
    const { repository_url } = req.body;
    const [[t]] = await db.query('SELECT student_id FROM theses WHERE id=?', [id]);
    if (!t) return res.status(404).json({ error: 'Not found' });
    if (t.student_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
    await db.query('UPDATE theses SET repository_url=? WHERE id=?', [repository_url, id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

// --- Secretariat: καταχώρηση ΑΠ ΓΣ ---
exports.setGSDecision = async (req, res, next) => {
  try {
    const { id } = req.params;
    required(req.body, ['decision_no']);
    await db.query('UPDATE theses SET secretariat_decision_no=? WHERE id=?', [req.body.decision_no, id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

// --- Ακύρωση ανάθεσης (μπορεί και ο επιβλέπων, ή η Γραμματεία) ---
exports.cancel = async (req, res, next) => {
  try {
    const { id } = req.params;
    required(req.body, ['reason']);
    const [[curr]] = await db.query('SELECT status FROM theses WHERE id=?', [id]);
    await db.query('UPDATE theses SET status=? WHERE id=?', ['cancelled', id]);
    await db.query(
      'INSERT INTO status_history (thesis_id, from_status, to_status, changed_by, reason) VALUES (?,?,?,?,?)',
      [id, curr ? curr.status : null, 'cancelled', req.user.id, req.body.reason]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
};

// --- Ολοκλήρωση (Περατωμένη) από Γραμματεία, εφόσον υπάρχουν βαθμοί + repo url ---
exports.completeIfEligible = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [[t]] = await db.query('SELECT repository_url, status FROM theses WHERE id=?', [id]);
    if (!t) return res.status(404).json({ error: 'Not found' });
    const allowNoRepo =
      String(process.env.ALLOW_COMPLETE_WITHOUT_NIMERITIS || '').toLowerCase() === 'true';
    // πρέπει να υπάρχουν 3 βαθμοί (ή όσα μέλη) και repository url
    const [[{ graders }]] = await db.query('SELECT COUNT(DISTINCT grader_id) AS graders FROM grades WHERE thesis_id=?', [id]);
    const [[{ committee_size }]] = await db.query('SELECT COUNT(*) AS committee_size FROM committee_members WHERE thesis_id=?', [id]);
    const required = Number(committee_size || 3);
    if ((!allowNoRepo && !t.repository_url) || Number(graders || 0) < required) {
    return res.status(400).json({ error: 'Missing grades or repository URL' });
    }

    await db.query('UPDATE theses SET status=?, completed_at=CURDATE() WHERE id=?', ['completed', id]);
    await db.query(
      'INSERT INTO status_history (thesis_id, from_status, to_status, changed_by) VALUES (?,?,?,?)',
      [id, t.status, 'completed', req.user.id]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
};

// --- HTML πρακτικό (βασικό) για προβολή από φοιτητή και μέλη τριμελούς ---
exports.praktikoHtml = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [[th]] = await db.query(
      `SELECT t.id, t.repository_url, t.secretariat_decision_no, t.review_date, t.review_location,
              s.first_name AS s_fn, s.last_name AS s_ln,
              tp.title
       FROM theses t
       JOIN users s ON s.id=t.student_id
       LEFT JOIN thesis_topics tp ON tp.id=t.topic_id
       WHERE t.id=?`, [id]
    );
    if (!th) return res.status(404).send('Not found');

    const [cm] = await db.query(
      `SELECT u.first_name, u.last_name, cm.is_supervisor
       FROM committee_members cm JOIN users u ON u.id=cm.faculty_id
       WHERE cm.thesis_id=?`, [id]
    );
    const [grades] = await db.query(
      `SELECT u.first_name, u.last_name, g.overall, g.criterion_1, g.criterion_2, g.criterion_3
       FROM grades g JOIN users u ON u.id=g.grader_id WHERE g.thesis_id=?`, [id]
    );

    // απλό HTML (μπορείς αργότερα να το βάλεις σε template)
    const avg = grades.length ? (grades.reduce((a,b)=>a+Number(b.overall||0),0)/grades.length).toFixed(2) : '-';
    const html = `
<!doctype html><html lang="el"><meta charset="utf-8">
<title>Πρακτικό εξέτασης</title>
<style>body{font-family:sans-serif;max-width:850px;margin:40px auto;padding:20px}
table{width:100%;border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px}</style>
<h2>Πρακτικό εξέτασης διπλωματικής</h2>
<p><b>Θέμα:</b> ${th.title || ''}</p>
<p><b>Φοιτητής/τρια:</b> ${th.s_ln} ${th.s_fn}</p>
<p><b>Ημ/νια – Χώρος:</b> ${th.review_date || '-'} – ${th.review_location || '-'}</p>
<p><b>ΑΠ ΓΣ:</b> ${th.secretariat_decision_no || '-'}</p>
<h3>Τριμελής</h3>
<ul>${cm.map(m=>`<li>${m.last_name} ${m.first_name}${m.is_supervisor?' (Επιβλέπων/ουσα)':''}</li>`).join('')}</ul>
<h3>Βαθμολογίες</h3>
<table>
<tr><th>Μέλος</th><th>Κριτ.1</th><th>Κριτ.2</th><th>Κριτ.3</th><th>Συνολικός</th></tr>
${grades.map(g=>`<tr><td>${g.last_name} ${g.first_name}</td><td>${g.criterion_1??''}</td><td>${g.criterion_2??''}</td><td>${g.criterion_3??''}</td><td>${g.overall??''}</td></tr>`).join('')}
<tr><th colspan="4" style="text-align:right">Μέσος όρος</th><th>${avg}</th></tr>
</table>
<p><b>Νημερτής:</b> ${th.repository_url ? `<a href="${th.repository_url}">${th.repository_url}</a>` : '-'}</p>
</html>`;
    res.type('text/html').send(html);
  } catch (e) { next(e); }
};

// --- Export CSV/JSON για διδάσκοντα ---
exports.exportMine = async (req, res, next) => {
  try {
    const { format='csv', status, role } = req.query;
    let sql = `
      SELECT t.id, t.status, tp.title, s.first_name AS s_fn, s.last_name AS s_ln,
             t.started_at, t.completed_at
      FROM theses t
      LEFT JOIN thesis_topics tp ON tp.id=t.topic_id
      JOIN users s ON s.id=t.student_id
      LEFT JOIN committee_members cm ON cm.thesis_id=t.id
      WHERE 1=1`;
    const params = [];
    if (role === 'supervisor') { sql += ' AND t.supervisor_id=?'; params.push(req.user.id); }
    else { sql += ' AND cm.faculty_id=?'; params.push(req.user.id); }
    if (status) { sql += ' AND t.status=?'; params.push(status); }
    sql += ' GROUP BY t.id ORDER BY t.id DESC';

    const [rows] = await db.query(sql, params);

    if (String(format).toLowerCase() === 'json') return res.json(rows);

    // CSV
    const header = 'id,status,title,student,started_at,completed_at\n';
    const csv = header + rows.map(r => [
      r.id, r.status, `"${(r.title||'').replace(/"/g,'""')}"`,
      `"${(r.s_ln + ' ' + r.s_fn).replace(/"/g,'""')}"`,
      r.started_at || '', r.completed_at || ''
    ].join(',')).join('\n');
    res.type('text/csv').send(csv);
  } catch (e) { next(e); }
};

exports.create = async (req, res) => {
  try {
    const supervisor_id = req.user.id;                // ο τρέχων διδάσκων
    const { topic_id, student_id, pdf } = req.body || {};

    if (!topic_id || !student_id)
      return res.status(400).json({ error: 'Missing topic_id or student_id' });

    // 1) Έλεγξε ότι το θέμα είναι δικό μου
    const [trows] = await db.query(
      'SELECT id FROM thesis_topics WHERE id=? AND created_by=? LIMIT 1',
      [topic_id, supervisor_id]
    );
    if (!trows.length) return res.status(403).json({ error: 'Topic not owned by you' });

    // 2) Έλεγξε ότι ο φοιτητής δεν έχει ήδη ενεργή/υπό ανάθεση διπλωματική
    const [exists] = await db.query(
      `SELECT id FROM theses 
       WHERE student_id=? AND status IN ('proposed','active','under_review') LIMIT 1`,
      [student_id]
    );
    if (exists.length) return res.status(409).json({ error: 'Student already has a thesis in progress' });

    // 3) Δημιούργησε thesis
    const [r] = await db.query(
      `INSERT INTO theses (topic_id, student_id, supervisor_id, status, started_at, draft_pdf)
       VALUES (?, ?, ?, 'proposed', NOW(), ?)`,
      [topic_id, student_id, supervisor_id, pdf || null]
    );

    res.status(201).json({ id: r.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.list = async (req, res, next) => {
  try {
    const { status, q, limit = 50, offset = 0 } = req.query;
    const statuses = status ? status.split(',') : [];
    const params = [];
    let where = '1=1';

    if (statuses.length) {
      where += ` AND t.status IN (${statuses.map(()=> '?').join(',')})`;
      params.push(...statuses);
    }
    if (q) {
      where += ` AND (t.topic LIKE ? OR CONCAT(s.last_name,' ',s.first_name) LIKE ? OR CONCAT(f.last_name,' ',f.first_name) LIKE ?)`;
      params.push(`%${q}%`,`%${q}%`,`%${q}%`);
    }

    const sql = `
      SELECT t.id, t.topic, t.description, t.status,
             t.started_at AS assigned_at, t.completed_at,
             t.secretariat_decision_no, t.repository_url,
             (SELECT ROUND(AVG(g.overall),2) FROM grades g WHERE g.thesis_id=t.id)        AS avg_grade,
             (SELECT COUNT(DISTINCT g.grader_id) FROM grades g WHERE g.thesis_id=t.id)    AS graders_count,
             CONCAT(s.last_name,' ',s.first_name) AS student_name, s.user_code AS student_am,
             CONCAT(f.last_name,' ',f.first_name) AS supervisor_name
      FROM theses t
      LEFT JOIN users s ON s.id=t.student_id
      LEFT JOIN users f ON f.id=t.supervisor_id
      WHERE ${where}  
      ORDER BY t.id DESC
      LIMIT ? OFFSET ?`;
    params.push(Number(limit), Number(offset));

    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) { next(e); }
};

exports.getOne = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [[t]] = await db.query(`
      SELECT t.*, CONCAT(s.last_name,' ',s.first_name) AS student_name, s.user_code AS student_am,
             CONCAT(f.last_name,' ',f.first_name) AS supervisor_name,
             (SELECT ROUND(AVG(g.overall),2) FROM grades g WHERE g.thesis_id=t.id)     AS avg_grade,
             (SELECT COUNT(DISTINCT g.grader_id) FROM grades g WHERE g.thesis_id=t.id) AS graders_count,
             (SELECT COUNT(*) FROM committee_members cm WHERE cm.thesis_id=t.id)       AS committee_size
      FROM theses t
      LEFT JOIN users s ON s.id=t.student_id
      LEFT JOIN users f ON f.id=t.supervisor_id
      WHERE t.id=?`, [id]);
    if (!t) return res.status(404).json({ error: 'Not found' });

    const [committee] = await db.query(`
      SELECT CONCAT(u.last_name,' ',u.first_name) AS name, cm.is_supervisor
      FROM committee_members cm
      JOIN users u ON u.id=cm.faculty_id
      WHERE cm.thesis_id=?
      ORDER BY cm.is_supervisor DESC, u.last_name, u.first_name`, [id]);

    res.json({ ...t, committee });
  } catch (e) { next(e); }
};

// ΛΙΣΤΑ για Γραμματεία, με φίλτρα κατάστασης & αναζήτηση
exports.listAll = async (req, res, next) => {
  try {
    const { status, q, limit = 50, offset = 0 } = req.query;
    const statuses = status ? status.split(',') : [];
    const params = [];
    let where = '1=1';

    if (statuses.length) {
      where += ` AND t.status IN (${statuses.map(()=> '?').join(',')})`;
      params.push(...statuses);
    }
    if (q) {
      where += ` AND (t.topic LIKE ? OR CONCAT(s.last_name,' ',s.first_name) LIKE ? OR CONCAT(f.last_name,' ',f.first_name) LIKE ?)`;
      params.push(`%${q}%`,`%${q}%`,`%${q}%`);
    }

    const sql = `
      SELECT t.id, t.topic, t.description, t.status,
             t.started_at AS assigned_at, t.completed_at,
             t.secretariat_decision_no, t.repository_url,
             (SELECT ROUND(AVG(g.overall),2) FROM grades g WHERE g.thesis_id=t.id)        AS avg_grade,
             (SELECT COUNT(DISTINCT g.grader_id) FROM grades g WHERE g.thesis_id=t.id)    AS graders_count,
             CONCAT(s.last_name,' ',s.first_name) AS student_name, s.user_code AS student_am,
             CONCAT(f.last_name,' ',f.first_name) AS supervisor_name
      FROM theses t
      LEFT JOIN users s ON s.id=t.student_id
      LEFT JOIN users f ON f.id=t.supervisor_id
      WHERE ${where}
      ORDER BY t.id DESC
      LIMIT ? OFFSET ?`;
    params.push(Number(limit), Number(offset));

    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) { next(e); }
};

// ΜΙΑ ΔΕ με τριμελή
exports.getOne = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [[t]] = await db.query(`
      SELECT t.*, CONCAT(s.last_name,' ',s.first_name) AS student_name, s.user_code AS student_am,
             CONCAT(f.last_name,' ',f.first_name) AS supervisor_name
      FROM theses t
      LEFT JOIN users s ON s.id=t.student_id
      LEFT JOIN users f ON f.id=t.supervisor_id
      WHERE t.id=?`, [id]);
    if (!t) return res.status(404).json({ error: 'Not found' });

    const [committee] = await db.query(`
      SELECT CONCAT(u.last_name,' ',u.first_name) AS name, cm.is_supervisor
      FROM committee_members cm
      JOIN users u ON u.id=cm.faculty_id
      WHERE cm.thesis_id=?
      ORDER BY cm.is_supervisor DESC, u.last_name, u.first_name`, [id]);

    res.json({ ...t, committee });
  } catch (e) { next(e); }
};
// GET /api/theses/:id/eligibility  -> πληροφορία ετοιμότητας για "Περατωμένη"
exports.eligibility = async (req, res, next) => {
  try {
    const { id } = req.params;

    const [[t]] = await db.query(
      `SELECT status, repository_url FROM theses WHERE id=? LIMIT 1`, [id]
    );
    if (!t) return res.status(404).json({ error: 'Not found' });

    const [[gc]] = await db.query(
      `SELECT COUNT(DISTINCT grader_id) AS graders_count FROM grades WHERE thesis_id=?`, [id]
    );
    const [[cs]] = await db.query(
      `SELECT COUNT(*) AS committee_size FROM committee_members WHERE thesis_id=?`, [id]
    );

    const gradersCount   = Number(gc?.graders_count || 0);
    const committeeSize  = Number(cs?.committee_size || 0);
    const hasRepo        = !!t.repository_url;

    // έχει όλους τους βαθμούς (τουλάχιστον όσοι η τριμελής, fallback: 3)
    const required = committeeSize || 3;
    const hasAllGrades = gradersCount >= required;

    const [[avg]] = await db.query(
      `SELECT ROUND(AVG(overall),2) AS avg_grade FROM grades WHERE thesis_id=?`, [id]
    );

    res.json({
      thesisId: Number(id),
      hasAllGrades,
      gradersCount,
      committeeSize,
      hasRepositoryUrl: hasRepo,
      avgGrade: avg?.avg_grade ?? null
    });
  } catch (e) { next(e); }
};

exports.listCompletedSupervised = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT
        t.id,
        t.status,
        DATE_FORMAT(t.completed_at, '%Y-%m-%d')          AS completed_at,
        DATE_FORMAT(t.review_date, '%Y-%m-%d %H:%i:%s')  AS review_date,
        t.review_location,
        t.repository_url,
        tp.title,
        tp.summary,
        s.first_name AS student_first_name,
        s.last_name  AS student_last_name,
        s.email      AS student_email
      FROM theses t
      JOIN thesis_topics tp ON tp.id = t.topic_id
      JOIN users s          ON s.id = t.student_id
      WHERE t.supervisor_id = ?
        AND (
          LOWER(TRIM(t.status)) = 'completed' OR
          LOWER(TRIM(t.status)) IN ('περατωμένη','περατωμενη')
        )
      ORDER BY t.completed_at DESC, t.id DESC
    `, [req.user.id]);

    res.json(rows);
  } catch (e) { next(e); }
};

exports.listUnderReviewSupervised = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT
        t.id, t.status,
        DATE_FORMAT(t.review_date,  '%Y-%m-%d %H:%i:%s') AS review_date,
        t.review_location, t.repository_url,
        tp.title, tp.summary,
        s.first_name AS student_first_name,
        s.last_name  AS student_last_name,
        s.email      AS student_email
      FROM theses t
      JOIN thesis_topics tp ON tp.id=t.topic_id
      JOIN users s          ON s.id=t.student_id
      WHERE t.supervisor_id=?
        AND LOWER(TRIM(t.status)) IN ('under_review','υπό εξέταση','υπο εξεταση')
      ORDER BY t.id DESC
    `, [req.user.id]);
    res.json(rows);
  } catch (e) { next(e); }
};

exports.listUnderReviewSupervised = async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT
        t.id, t.status,
        DATE_FORMAT(t.review_date,  '%Y-%m-%d %H:%i:%s') AS review_date,
        t.review_location, t.repository_url,
        tp.title, tp.summary,
        s.first_name AS student_first_name,
        s.last_name  AS student_last_name,
        s.email      AS student_email
      FROM theses t
      JOIN thesis_topics tp ON tp.id=t.topic_id
      JOIN users s          ON s.id=t.student_id
      WHERE t.supervisor_id=?
        AND LOWER(TRIM(t.status)) IN ('under_review','υπό εξέταση','υπο εξεταση')
      ORDER BY t.id DESC
    `, [req.user.id]);

    res.json(rows);
  } catch (e) { next(e); }
};
