import { API } from './api.js';

async function loadTopics(){
const list = document.getElementById('topicsList');
const data = await API.topics.listMine();
list.innerHTML = data.map(t => `
<li class="list-group-item d-flex justify-content-between align-items-start">
<div>
<h6 class="mb-1">${t.title}</h6>
<small class="text-muted">${t.summary}</small><br>
${t.pdf ? `<small><a href="${t.pdf}" target="_blank">📄 PDF</a></small>` : ''}
</div>
<button class="btn btn-sm btn-outline-secondary" data-id="${t.id}">✏️ Επεξεργασία</button>
</li>`).join('');
}

async function createTopic(){
const f = document.getElementById('newTopicForm');
f?.addEventListener('submit', async (e) => {
e.preventDefault();
const title = f.title.value, summary = f.summary.value; let pdfPath=null;
const file = f.pdf.files[0];
if (file){ // ανέβασμα pdf πρώτα
const fd = new FormData(); fd.append('file', file);
const r = await fetch('http://localhost:3000/api/files/upload', { method:'POST', headers: { 'Authorization': 'Bearer '+localStorage.getItem('jwt') }, body: fd });
const j = await r.json(); pdfPath = j.path;
}
await API.topics.create({ title, summary, pdf: pdfPath });
f.reset();
await loadTopics();
});
}

async function assignThesis(){
const f = document.getElementById('assignForm');
f?.addEventListener('submit', async (e) => {
e.preventDefault();
await API.theses.assign(Number(f.topic_id.value), Number(f.student_id.value));
alert('Ανατέθηκε προσωρινά!');
});
}

window.didLoad = () => { loadTopics(); createTopic(); assignThesis(); };