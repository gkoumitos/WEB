// front-end/assets/js/common.js
import { clearToken } from './api.js';

// Διάβασε στοιχεία χρήστη από το JWT (payload)
export function getCurrentUser() {
  const token = localStorage.getItem('jwt');
  if (!token) return null;
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const { id, role, first_name, last_name, email } = payload || {};
    if (!id || !role) return null;
    return { id, role, first_name, last_name, email };
  } catch (e) {
    return null;
  }
}

// Απαιτεί login και (προαιρετικά) συγκεκριμένους ρόλους
export function requireAuth(allowedRoles = null) {
  const u = getCurrentUser();
  if (!u) {
    location.href = '/login.html';  // ή το δικό σου login path
    return null;
  }
  if (Array.isArray(allowedRoles) && !allowedRoles.includes(u.role)) {
    location.href = '/403.html';    // απλή σελίδα “δεν έχετε πρόσβαση”
    return null;
  }
  return u;
}

// Γεμίζει τον χαιρετισμό σε ένα element (π.χ. <h2 id="greet">)
export function setGreeting(selector = '#greet') {
  const u = getCurrentUser();
  if (!u) return;
  const el = document.querySelector(selector);
  if (el) el.textContent = `Καλωσορίσατε, ${u.first_name} ${u.last_name}!`;
}

// Γεμίζει placeholders ονόματος/email όπου χρειάζεσαι
export function populateUserPlaceholders() {
  const u = getCurrentUser();
  if (!u) return;
  document.querySelectorAll('[data-user-fullname]')
    .forEach(el => el.textContent = `${u.first_name} ${u.last_name}`);
  document.querySelectorAll('[data-user-firstname]')
    .forEach(el => el.textContent = u.first_name);
  document.querySelectorAll('[data-user-email]')
    .forEach(el => el.textContent = u.email);
}

// Logout
export function logout() {
  clearToken();
  location.href = '/index.html'; // ή όπου θέλεις να επιστρέφεις
}

// Κάν’ το διαθέσιμο για onclick σε κουμπιά
window.logout = logout;