INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1000', 'Βαλάντω', 'Μπακοστεργίου', 'valanto.mpakostergioy@mail.gr',
        '$2b$12$Xw7WOuGi4kWxgvVIgZmJiO.g6EYG1crb7q90/cSIDgmQl022goYd.', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1001', 'Πραξιτέλης', 'Κωτσιονοπούλου', 'praxitelis.kotsionopoyloy@mail.gr',
        '$2b$12$g8KRl7WmoD/MbkyrJMi3JOmEyRFPoCHtcrivX8SdE3S/6lRxjc/8C', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1002', 'Μαγδαληνή', 'Ταμιωλάκης', 'magdalini.tamiolakis@mail.gr',
        '$2b$12$YY9Z9uOR5hgWVeTMJHOtlOJ/sOGpeyprQCckqAWqsiez1dusbXgpu', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1003', 'Ελευθέριος', 'Γκούβελος', 'eleytherios.gkoyvelos@mail.gr',
        '$2b$12$TNkHxHeerft/sz9qBpuG.eiXSnaIyklsgvNief81jLIfKtCAXqWIC', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1004', 'Αριστείδης', 'Αβραμίδου', 'aristeidis.avramidoy@mail.gr',
        '$2b$12$vMLBEkhDz1QgIR79sU0dtOJ2umR9untHS7d1YLdwVttnGzoJZDCjy', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1005', 'Θεοδότη', 'Τσώνης', 'theodoti.tsonis@mail.gr',
        '$2b$12$mpflCe2aoH.hQjqzSOu1wuN8LGzKXzgFRXKxi.DZ/mEP8GV0R3lAm', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1006', 'Χρυσή', 'Θεοδωρόπουλος', 'chrysi.theodoropoylos@mail.gr',
        '$2b$12$nM1ZkXbyUpqR0a9lK8X2ze0smHc6YrRaoyop5h9bOt2ohcBOemn8C', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1007', 'Ρηγούλα', 'Παπαγιάννης', 'rigoyla.papagiannis@mail.gr',
        '$2b$12$UBPllsrINOn1/ga90Bz8VOu2Glv2MdhMHkUK0d09SjhTb6DNfb/ei', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1008', 'Διογένης', 'Σαμαράς', 'diogenis.samaras@mail.gr',
        '$2b$12$.vK3mc9VkNj9zt33.0zfquFJ4uECec5ZitmCTAM9TA71JUfZ.vr0O', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );
INSERT INTO users (role, user_code, first_name, last_name, email, password_hash, phone_mobile, phone_landline, address, created_at) VALUES (
        'student', 'A1009', 'Γαλήνη', 'Λαγοπάτης', 'galini.lagopatis@mail.gr',
        '$2b$12$mYWIEvzmIYTiHnwPkSMmkeFln4OjmbT5WywqxJSpQW1kexU6hMbyC', '6900000000', '2100000000', 'Διεύθυνση', NOW()
    );