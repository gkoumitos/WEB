const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();
const path = require('path'); // ΜΟΝΟ μία φορά

const app = express();

app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
/* PATCH: dynamic CORS */
const allowedOrigins = (process.env.ALLOWED_ORIGIN || process.env.ALLOWED_ORIGINS || 'http://127.0.0.1:5500,http://localhost:5500')
  .split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: function(origin, callback) {
    // allow requests with no origin (like mobile apps or curl / local file://)
    if (!origin) return callback(null, true);
    if (allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    return callback(new Error('Not allowed by CORS: ' + origin));
  },
  credentials: false,
  allowedHeaders: ['Content-Type', 'Authorization'],
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS']
}));
app.options('*', cors()); // enable pre-flight for all routes


// rate limit για login
const authLimiter = rateLimit({ windowMs: 5 * 60 * 1000, max: 50 });
app.use('/api/auth', authLimiter);

// static uploads με caching
const staticTTL = Number(process.env.STATIC_TTL || 604800);
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), {
  setHeaders: (res) => res.set('Cache-Control', `public, max-age=${staticTTL}`)
}));

// routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/topics', require('./routes/topics'));
app.use('/api/theses', require('./routes/theses'));
app.use('/api/invitations', require('./routes/invitations'));
app.use('/api/notes', require('./routes/notes'));
app.use('/api/grades', require('./routes/grades'));
app.use('/api/files', require('./routes/files'));
app.use('/api/import', require('./routes/import'));
app.use('/api/stats', require('./routes/stats'));
app.use('/feed', require('./routes/feed')); // δημόσιο

// error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server at http://localhost:${PORT}`));