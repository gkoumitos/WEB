const db = require('../db');
const { required } = require('../middleware/validate');

exports.assignToStudent = async (req, res, next) => {
  try {
    required(req.body, ['topic_id', 'student_id']);
    const { topic_id, student_id } = req.body;

    const [r] = await db.query(
      'INSERT INTO theses (topic_id, student_id, supervisor_id, status, started_at) VALUES (?,?,?,?,CURDATE())',
      [topic_id, student_id, req.user.id, 'proposed']
    );
    const thesisId = r.insertId;

    await db.query(
      'INSERT INTO status_history (thesis_id, from_status, to_status, changed_by) VALUES (?,?,?,?)',
      [thesisId, null, 'proposed', req.user.id]
    );

    res.status(201).json({ id: thesisId });
  } catch (e) { next(e); }
};

exports.listMine = async (req, res, next) => {
  try {
    let sql = `
      SELECT t.id, t.status, tp.title,
             s.first_name AS student_first_name, s.last_name AS student_last_name
      FROM theses t
      JOIN thesis_topics tp ON tp.id = t.topic_id
      JOIN users s ON s.id = t.student_id
      WHERE 1=1`;
    const params = [];

    if (req.user.role === 'faculty') {
      sql += ' AND (t.supervisor_id = ? OR EXISTS (SELECT 1 FROM committee_members cm WHERE cm.thesis_id=t.id AND cm.faculty_id=?))';
      params.push(req.user.id, req.user.id);
    }
    if (req.user.role === 'student') {
      sql += ' AND t.student_id = ?';
      params.push(req.user.id);
    }
    // secretariat: βλέπει τα πάντα – δεν φιλτράρουμε

    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) { next(e); }
};

exports.changeStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    required(req.body, ['status']);
    const { status, reason } = req.body;

    const [[curr]] = await db.query('SELECT status FROM theses WHERE id=?', [id]);
    await db.query('UPDATE theses SET status=? WHERE id=?', [status, id]);
    await db.query(
      'INSERT INTO status_history (thesis_id, from_status, to_status, changed_by, reason) VALUES (?,?,?,?,?)',
      [id, curr ? curr.status : null, status, req.user.id, reason || null]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
};