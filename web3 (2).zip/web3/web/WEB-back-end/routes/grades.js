// routes/grades.js
const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const ctrl = require('../controllers/gradesController');

router.get('/:thesisId', authenticate, ctrl.list);             // όλοι οι βαθμοί της διπλωματικής
router.get('/:thesisId/mine', authenticate, ctrl.mine);        // ο δικός μου βαθμός
router.post('/:thesisId/mine', authenticate, ctrl.upsertMine); // insert/update ο δικός μου

module.exports = router;
