// front-end/assets/js/api.js
const API_BASE = (window.API_BASE)
  ? window.API_BASE
  : (location.hostname ? `http://${location.hostname}:3000` : 'http://localhost:3000');

let TOKEN = localStorage.getItem('jwt');

export function setToken(t){ TOKEN = t; localStorage.setItem('jwt', t); }
export function clearToken(){ TOKEN = null; localStorage.removeItem('jwt'); }

async function req(path, opts = {}){
  const headers = { ...(opts.headers || {}) };
  // Αν ΔΕΝ στέλνουμε FormData, βάλε JSON Content-Type
  if (!(opts.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  if (TOKEN) headers['Authorization'] = 'Bearer ' + TOKEN;

  const res = await fetch(API_BASE + path, { ...opts, headers });

  if (res.status === 204) return null;

  let data = null;
  try { data = await res.json(); } catch (_) {}

  if (!res.ok) {
    const msg = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

export const API = {
  // Backwards-compatible: το front-end σου καλεί API.login(email, password)
  login: (email, password) => req('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  }),

  // Προαιρετικά namespace, αλλά κάνει delegate στο παραπάνω
  auth: {
    login: (email, password) => API.login(email, password),
    me: () => req('/api/auth/me'),
    logout: async () => { clearToken(); }
  },

  files: {
      upload: async (formData) => {
        const headers = {};
        const token = localStorage.getItem('jwt');
        if (token) headers['Authorization'] = 'Bearer ' + token;

        // Μην ορίσεις Content-Type χειροκίνητα — το βάζει ο browser για multipart
        const tryUpload = async (path) => {
          const r = await fetch(API_BASE + path, { method: 'POST', headers, body: formData });
          // Αν δεν είναι 2xx, πάρε κείμενο ώστε να δούμε ΤΙ έγινε
          const t = await r.text();
          if (!r.ok) {
            const msg = (() => {
              try { return JSON.parse(t)?.error || t; } catch { return t; }
            })();
            const err = new Error(`Upload failed (${r.status}): ${msg}`);
            err.status = r.status;
            throw err;
          }
          // ιδανικά { path: '/uploads/...' }
          try { return JSON.parse(t); } catch { return { path: t }; }
        };

        // 1η προσπάθεια: /api/files/upload
        try {
          return await tryUpload('/api/files/upload');
        } catch (e) {
          // Αν είναι 404, δοκίμασε /api/files
          if (e.status === 404) {
            return await tryUpload('/api/files');
          }
          throw e;
        }
      }
    },

    users: {
      me:      () => req('/api/users/me'),
      update:  (payload) => req('/api/users/me', {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),
      searchStudents: (q) => req(`/api/users/search?role=student&q=${encodeURIComponent(q||'')}`),
      getByCode: (code) => req(`/api/users/by-code/${encodeURIComponent(code)}`)
  },
    
    faculty: {
    list: ({ q, thesis_id } = {}) => {
      const qs = new URLSearchParams();
      if (q) qs.set('q', q);
      if (thesis_id) qs.set('thesis_id', thesis_id);
      return req('/api/faculty' + (qs.toString() ? `?${qs.toString()}` : ''));
    }
  },
  
    topics: {
      // το list για τον διδάσκοντα: GET /api/topics/ (επιστρέφει μόνο τα δικά του)
      mine:    () => req('/api/topics/'),
      listMine:() => req('/api/topics/'), // alias

      // create περιμένει { title, summary, pdf }
      create:  (payload) => req('/api/topics/', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

      // αν θέλεις toggle, χρησιμοποίησε PUT /api/topics/:id με { is_active }
      update:  (id, payload) => req(`/api/topics/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),
    },



    invitations: {
      mine:   () => req('/api/invitations/mine'),

      // Δουλεύει και με create({ thesis_id, faculty_id }) ΚΑΙ με create(thesis_id, faculty_id)
      create: (a, b) => {
        const payload = (typeof a === 'object' && a !== null)
          ? a
          : { thesis_id: a, faculty_id: b };
        return req('/api/invitations', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      },

      respond: (id, response) =>
        req(`/api/invitations/${id}/respond`, {
          method: 'POST',
          body: JSON.stringify({ response }),
        }),

      accept: (id) => req(`/api/invitations/${id}/accept`,  { method: 'POST' }),
      decline:(id) => req(`/api/invitations/${id}/decline`, { method: 'POST' }),
    },
    theses: {
      mine: () => req('/api/theses/mine'),
      create: (payload) => req('/api/theses', {           // { topic_id, student_id, pdf? }
        method: 'POST',
        body: JSON.stringify(payload)
      }),
      changeStatus: (id, status) => req(`/api/theses/${id}/status`, {
        method: 'POST',
        body: JSON.stringify({ status })
      }),
      draft: (id, path) => req(`/api/theses/${id}/draft`, {
        method: 'POST',
        body: JSON.stringify({ path })
      }),
      getDraft: (id) => req(`/api/theses/${id}/draft`),
      addLink: (id, url) => req(`/api/theses/${id}/links`, {
        method: 'POST',
        body: JSON.stringify({ url })
      }),
      listLinks: (id) => req(`/api/theses/${id}/links`),
      setRepository: (id, url) => req(`/api/theses/${id}/repository`, {
        method: 'POST',
        body: JSON.stringify({ url })
      }),
      setReview: (id, payload) => req(`/api/theses/${id}/review`, {
        method: 'POST',
        body: JSON.stringify(payload) // { review_date, review_location }
      }),
    },
    stats: {
      // επιστρέφει:
      // { avg_days_supervisor, avg_grade_supervisor, total_supervised,
      //   avg_days_member,     avg_grade_member,     total_member }
      mine: () => req('/api/stats/mine')
    },
  }
