import { API } from './api.js';

async function loadMyThesis(){
const data = await API.theses.mine();
const container = document.getElementById('myThesis');
if (!data.length) return container.innerHTML = '<em>Δεν έχει ανατεθεί διπλωματική.</em>';
const t = data[0];
container.innerHTML = `<h5>${t.title}</h5><span class="badge bg-info">${t.status}</span>`;
}

async function inviteMember(){
const f = document.getElementById('inviteForm');
f?.addEventListener('submit', async (e)=>{
e.preventDefault();
await API.invitations.create(Number(f.thesis_id.value), Number(f.faculty_id.value));
alert('Πρόσκληση στάλθηκε');
});
}

async function uploadDraft(){
const f = document.getElementById('draftForm');
f?.addEventListener('submit', async (e)=>{
e.preventDefault();
const fd = new FormData(); fd.append('file', f.draft.files[0]);
const r = await fetch('http://localhost:3000/api/files/upload', { method:'POST', headers: { 'Authorization': 'Bearer '+localStorage.getItem('jwt') }, body: fd });
const j = await r.json();
document.getElementById('draftLink').innerHTML = `<a href="${j.path}" target="_blank">Πρόχειρο</a>`;
});
}

window.foitLoad = () => { loadMyThesis(); inviteMember(); uploadDraft(); };