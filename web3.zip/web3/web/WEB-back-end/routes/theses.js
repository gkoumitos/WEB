const router = require('express').Router();
const ctrl = require('../controllers/thesesController');
const { authenticate, authorize } = require('../middleware/auth');

// Διδάσκων: αρχική ανάθεση
router.post('/assign', authenticate, authorize('faculty'), ctrl.assignToStudent);

// Προβολή ανά χρήστη
router.get('/mine', authenticate, ctrl.listMine);

// Αλλαγές κατάστασης
router.post('/:id/status', authenticate, ctrl.changeStatus);

module.exports = router;