const db = require('../db');
const { required } = require('../middleware/validate');

exports.listMine = async (req, res) => {
  const [rows] = await db.query(
    `SELECT
       id,
       title,
       summary,
       description_file AS pdf,
       created_at,
       created_by,
       COALESCE(is_active, 0) AS is_active
     FROM thesis_topics
     WHERE created_by = ?
     ORDER BY created_at DESC`,
    [req.user.id]
  );

  // κανονικοποίηση σε boolean (true όταν 1)
  const data = rows.map(r => ({
    ...r,
    is_active: Number(r.is_active) === 1
  }));

  res.json(data);
};



exports.create = async (req, res, next) => {
  try {
    required(req.body, ['title', 'summary']);
    const { title, summary, pdf } = req.body; // pdf -> description_file
    const [r] = await db.query(
      'INSERT INTO thesis_topics (title, summary, description_file, created_by) VALUES (?,?,?,?)',
      [title, summary, pdf || null, req.user.id]
    );
    res.status(201).json({ id: r.insertId });
  } catch (e) { next(e); }
};

// PUT /api/topics/:id
exports.update = async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { title, summary, pdf, is_active } = req.body || {};

    const fields = [];
    const params = [];

    if (title !== undefined)   { fields.push('title = ?');              params.push(title); }
    if (summary !== undefined) { fields.push('summary = ?');            params.push(summary); }
    if (pdf !== undefined)     { fields.push('description_file = ?');   params.push(pdf); }
    if (is_active !== undefined) {
      fields.push('is_active = ?');
      params.push(is_active ? 1 : 0); // boolean -> 0/1
    }

    if (!fields.length) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    params.push(id, req.user.id);

    const [r] = await db.query(
      `UPDATE thesis_topics SET ${fields.join(', ')}
       WHERE id = ? AND created_by = ? LIMIT 1`,
      params
    );
    if (!r.affectedRows) return res.status(404).json({ error: 'Topic not found' });

    // γύρνα το ενημερωμένο row (και κανονικοποίησε το is_active)
    const [rows] = await db.query(
      `SELECT id, title, summary, description_file AS pdf, is_active
       FROM thesis_topics WHERE id = ?`, [id]
    );
    const row = rows[0];
    row.is_active = Number(row.is_active) === 1;
    res.json(row);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};
